package com.zking.crm.statistics.stituemydview.dao;

import java.util.List;

import com.zking.crm.statistics.stituemydview.model.StitueMydView;

public interface IStitueMydViewDao {
	/**
	 * 查询所有
	 * @return
	 */
List<StitueMydView> listStitueView();
}
