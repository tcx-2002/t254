package com.zking.crm.client.drain.service;

import java.util.List;

import com.zking.crm.client.drain.dao.IDrainDao;
import com.zking.crm.client.drain.model.Drain;
import com.zking.crm.util.PageBean;

public class DrainServiceImpl implements IDrainService{
private IDrainDao drainDao;

public IDrainDao getDrainDao() {
	return drainDao;
}

public void setDrainDao(IDrainDao drainDao) {
	this.drainDao = drainDao;
}

@Override
public List<Drain> listDrain(Drain drain, PageBean pageBean) {
	// TODO Auto-generated method stub
	return drainDao.listDrain(drain, pageBean);
}

@Override
public void addDrain(Drain drain) {
	// TODO Auto-generated method stub
	drainDao.addDrain(drain);
}

}
