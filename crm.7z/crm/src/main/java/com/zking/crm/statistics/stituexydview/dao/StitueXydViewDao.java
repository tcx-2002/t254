package com.zking.crm.statistics.stituexydview.dao;

import java.util.List;

import com.zking.crm.common.dao.BaseDao;
import com.zking.crm.statistics.stituexydview.model.StitueXydView;

public class StitueXydViewDao extends BaseDao implements IStitueXydViewDao{

	@Override
	public List<StitueXydView> listStitue() {
		String hql = "select s from StitueXydView s";
		List<StitueXydView> list = (List<StitueXydView>)this.getHibernateTemplate().find(hql);
		return list;
	}

}
