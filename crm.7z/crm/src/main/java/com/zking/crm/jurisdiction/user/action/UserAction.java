package com.zking.crm.jurisdiction.user.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


import com.opensymphony.xwork2.ModelDriven;
import com.zking.crm.common.action.BaseAction;
import com.zking.crm.jurisdiction.user.model.User;
import com.zking.crm.jurisdiction.user.service.IUserService;
import com.zking.crm.util.JwtUtils;

public class UserAction extends BaseAction implements ModelDriven<User> {
	
	private User user = new User();
	
	@Override
	public User getModel() {
		return user;
	}

    private IUserService userService;
    
    public IUserService getUserService() {
		return userService;
	}

	public void setUserService(IUserService userService) {
		this.userService = userService;
	}
	
	public void login() {
		System.out.println(user.getUsrName());
		System.out.println(user.getUsrPassword());
		
		Map<String,Object> map = new HashMap<>();
		User user = userService.login(this.user);
		if(user!=null) {
			
			map.put("success", true);
			map.put("msg", "登录成功");
			map.put("user", user);
//			//登录成功给一个jwt令牌
//			Map<String,Object> param = new HashMap<>();
//			param.put("user", user);
//			String jwt = JwtUtils.createJwt(param, JwtUtils.JWT_WEB_TTL);
//			ServletActionContext.getResponse().addHeader("jwt", jwt);
			
			this.writeAsJson(map);
		} else {
			map.put("success", false);
			map.put("msg", "登录失败");
			this.writeAsJson(map);
		}
	}
	public void addUser() {
		Map<String, Object> map = new HashMap<>();
		Integer n = userService.addUser(user);
		if (n>0) {
			map.put("success", true);
			map.put("msg", "增加成功");
			this.writeAsJson(map);
		}else {
			map.put("success", false);
			map.put("msg", "增加失败");
			this.writeAsJson(map);
		}
	}
	//处理查询所有客户经理的ACTION
	public void userAM() {
		Map<String, Object> map = new HashMap<>();
		List<User> users = userService.userAM();
		map.put("users", users);
		this.writeAsJson(map);
	}
	/**
	 *查询客户满意度 
	 */
	public void selCustManagerName() {
		List<User> datas = userService.selCustManagerName();
		this.writeAsJson(datas);
	}

	public void userById() {
		System.out.println(this.user.getUsrId());
		Map<String, Object> map = new HashMap<>();
		User user = userService.userById(this.user.getUsrId());
		map.put("user", user);
		this.writeAsJson(map);
	}

}
