package com.zking.crm.marketing.salchance.service;

import java.util.List;

import com.zking.crm.marketing.salchance.dao.ISalChanceDao;
import com.zking.crm.marketing.salchance.model.SalChance;
import com.zking.crm.util.PageBean;

public class SalChanceService implements ISalChanceService{
private ISalChanceDao salChanceDao;

public ISalChanceDao getSalChanceDao() {
	return salChanceDao;
}

public void setSalChanceDao(ISalChanceDao salchanceDao) {
	this.salChanceDao = salchanceDao;
}

@Override
public List<SalChance> SalChanceList(SalChance salchance,PageBean pagebean) {
	// TODO Auto-generated method stub
	return salChanceDao.SalChanceList(salchance,pagebean);
}

@Override
public Integer addSalChance(SalChance salchance) {
	// TODO Auto-generated method stub
	return salChanceDao.addSalChance(salchance);
}

@Override
public void updateSalChance(SalChance salchance) {
	salChanceDao.updateSalChance(salchance);
}

@Override
public void deleteSalChance(long chcId) {
	salChanceDao.deleteSalChance(chcId);
}

@Override
public SalChance salChanceById(long chcId) {
	// TODO Auto-generated method stub
	return salChanceDao.salChanceById(chcId);
}


}
