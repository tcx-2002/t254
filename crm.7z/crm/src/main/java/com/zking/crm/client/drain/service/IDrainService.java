package com.zking.crm.client.drain.service;

import java.util.List;

import com.zking.crm.client.drain.model.Drain;
import com.zking.crm.util.PageBean;

public interface IDrainService {
	/**
	 * 分页查询所有
	 * @param drain
	 * @param pageBean
	 * @return
	 */
	List<Drain> listDrain(Drain drain,PageBean pageBean);
	/**
	 * 增加客户流失数据
	 * @param drain
	 */
	void addDrain(Drain drain);
}
