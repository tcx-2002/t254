package com.zking.crm.serve.cstserviceview.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.zking.crm.common.dao.BaseDao;
import com.zking.crm.serve.cstserviceview.model.CstServiceView;

public class CstServiceViewDao extends BaseDao implements ICstServiceViewDao{

	@Override
	public List<CstServiceView> listCstServiceView(CstServiceView cstServiceView) {
		String hql = "select c from CstServiceView c where c.cdate=?";
		List<CstServiceView> list =(List<CstServiceView>) this.getHibernateTemplate().find(hql,cstServiceView.getCdate());
		return list;
	}

	@Override
	public List<CstServiceView> listCdate() {
		String hql = "select c.cdate from CstServiceView c group by c.cdate";
		return (List<CstServiceView>)this.getHibernateTemplate().find(hql);
	}

	@Override
	public void addCount(CstServiceView cstServiceView) {
		String hqladd = "select c from CstServiceView c where c.cdate=?";
		List<CstServiceView> addlist =(List<CstServiceView>) this.getHibernateTemplate().find(hqladd, cstServiceView.getCdate());
		if(addlist.size()<1) {
			String[] citem = {"咨询","建议","投诉"};
			for (int i = 0; i < 3; i++) {
				String addItemHql ="insert into CstServiceView(citem,cdate)value(?,?)";
				this.getHibernateTemplate().find(addItemHql, new String[] {citem[i],cstServiceView.getCdate()});
			}
		}
		// TODO Auto-generated method stub
		String hql = "select c from CstServiceView c where c.cdate=? and c.citem=?";
		List<CstServiceView> csts = (List<CstServiceView>)this.getHibernateTemplate().find(hql, new String[] {cstServiceView.getCdate(),cstServiceView.getCitem()});
		CstServiceView cst = csts.get(0);
		if(cst!=null) {
			cst.setCount(cst.getCount()+1);
		}
	}

	@Override
	public List<CstServiceView> listServiceView(Integer cdate) {
		String hql = "select c from CstServiceView c where c.cdate>=? and c.cdate<? ORDER BY c.cdate ASC";
		Integer cdateleft = cdate-5;
		Integer cdateto = cdate+5;
		List<CstServiceView> list =(List<CstServiceView>) this.getHibernateTemplate().find(hql, new String[] {cdateleft.toString(),cdateto.toString()});
		return list;
	}

	@Override
	public List<CstServiceView> listCdate(Integer cdate) {
		String hql = "select c.cdate from CstServiceView c where c.cdate>=? and c.cdate<? group by c.cdate";
		Integer cdateleft = cdate-5;
		Integer cdateto = cdate+5;
		List<CstServiceView> list = (List<CstServiceView>)this.getHibernateTemplate().find(hql, new String[] {cdateleft.toString(),cdateto.toString()});
		return list;
	}

//	@Override
//	public List<List<CstServiceView>> listServiceView(String[] options) {
//		CstServiceView[] cstviews = new CstServiceView[options.length];
//		List<List<CstServiceView>> cst = new ArrayList<>();
//		for (int i = 0; i < options.length; i++) {
//			String hql = "select c from CstServiceView c where c.cdate=?";
//			List<CstServiceView> csts =(List<CstServiceView>) this.getHibernateTemplate().find(hql, options[i]);
//			cst.add(csts);
//		}
//		return cst;
//	}

	
}
