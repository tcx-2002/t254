package com.zking.crm.statistics.stitueView.dao;

import java.util.List;

import com.zking.crm.statistics.stitueView.model.StitueView;

public interface IStitueViewDao {
	/**
	 * 查询所有
	 * @return
	 */
List<StitueView> listStitueView();
}
