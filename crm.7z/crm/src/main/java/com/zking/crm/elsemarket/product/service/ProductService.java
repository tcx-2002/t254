package com.zking.crm.elsemarket.product.service;

import java.util.List;

import com.zking.crm.elsemarket.product.dao.IProductDao;
import com.zking.crm.elsemarket.product.model.Product;
import com.zking.crm.util.PageBean;

public class ProductService implements IProductService{
private IProductDao productDao;

public IProductDao getProductDao() {
	return productDao;
}

public void setProductDao(IProductDao productDao) {
	this.productDao = productDao;
}

@Override
public List<Product> listProduct(Product product, PageBean pageBean) {
	// TODO Auto-generated method stub
	return productDao.listProduct(product, pageBean);
}

@Override
public Product productByid(int prod_id) {
	// TODO Auto-generated method stub
	return productDao.productByid(prod_id);
}

@Override
public Product selProduct(Product product) {
	// TODO Auto-generated method stub
	return productDao.selProduct(product);
}

@Override
public List<Product> listProductName() {
	// TODO Auto-generated method stub
	return productDao.listProductName();
}

}
