package com.zking.crm.serve.cstservice.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ModelDriven;
import com.zking.crm.basics.basdict.model.BasDict;
import com.zking.crm.common.action.BaseAction;
import com.zking.crm.serve.cstservice.model.CstService;
import com.zking.crm.serve.cstservice.service.ICstServiceService;
import com.zking.crm.serve.cstserviceview.model.CstServiceView;
import com.zking.crm.util.PageBean;

public class CstServiceAction extends BaseAction implements ModelDriven<CstService> {
	private CstService cstService = new CstService();

	@Override
	public CstService getModel() {
		// TODO Auto-generated method stub
		return cstService;
	}

	private ICstServiceService cstServiceService;

	public ICstServiceService getCstServiceService() {
		return cstServiceService;
	}

	public void setCstServiceService(ICstServiceService cstServiceService) {
		this.cstServiceService = cstServiceService;
	}

	public void addCstService() {
		System.out.println(cstService);
		Map<String, Object> map = new HashMap<>();
		try {
			cstServiceService.addCstService(cstService);
			map.put("success", true);
			map.put("msg", "增加成功");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			map.put("success", false);
			map.put("msg", "增加失败");
		}
		this.writeAsJson(map);
	}
	
	public void listCstService() {
		System.out.println(cstService);
		PageBean pageBean = new PageBean();
		pageBean.setRequest(ServletActionContext.getRequest());
		List<CstService> list = cstServiceService.listCstService(cstService, pageBean);
		Map<String, Object> data = new HashMap<>();
		data.put("total", pageBean.getTotal());
		data.put("totalPageNum", pageBean.getTotalPageNum());
		data.put("page", pageBean.getPage());
		data.put("rows", pageBean.getRows());
		data.put("data", list);
		this.writeAsJson(data);
	}
	
	public void updateCstService() {
		System.out.println(cstService);
		Map<String, Object> map = new HashMap<>();
		try {
			cstServiceService.updateCtsService(cstService);
			map.put("success", true);
			map.put("msg", "修改成功");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			map.put("success", false);
			map.put("msg", "修改失败");
		}
		this.writeAsJson(map);
	}
	public void deleteCstService() {
		System.out.println(cstService.getSvrId());
		Map<String, Object> map = new HashMap<>();
		try {
			cstServiceService.deleteCstService(cstService.getSvrId());
			map.put("success", true);
			map.put("msg", "删除成功");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			map.put("success", false);
			map.put("msg", "删除失败");
		}
		this.writeAsJson(map);
	}
}
