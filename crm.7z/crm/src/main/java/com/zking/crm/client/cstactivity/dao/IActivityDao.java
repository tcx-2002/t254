package com.zking.crm.client.cstactivity.dao;

import java.util.List;

import com.zking.crm.client.cstactivity.model.CstActivity;
import com.zking.crm.util.PageBean;


public interface IActivityDao {
	
	/**
	 * 查询联系人
	 * @param custNo
	 * @return
	 */
	public List<CstActivity> selCstActivity(String atvCustNo);
	
	
	public List<CstActivity> getCstActivityPage(CstActivity activity,PageBean pageBean);

	public void addCstActivity(CstActivity activity);
	
	public void updateCstActivity(CstActivity activity);
	
	public void delCstActivity(CstActivity activity);

}
