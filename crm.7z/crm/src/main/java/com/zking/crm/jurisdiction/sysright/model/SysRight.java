package com.zking.crm.jurisdiction.sysright.model;



public class SysRight{
	private String rightCode;
	private String rightParentCode;
	private String rightType;
	private String rightText;
	private String rightUrl;
	private String rightTip;
	public void setRightCode(String rightCode){
	this.rightCode=rightCode;
	}
	public String getRightCode(){
		return rightCode;
	}
	public void setRightParentCode(String rightParentCode){
	this.rightParentCode=rightParentCode;
	}
	public String getRightParentCode(){
		return rightParentCode;
	}
	public void setRightType(String rightType){
	this.rightType=rightType;
	}
	public String getRightType(){
		return rightType;
	}
	public void setRightText(String rightText){
	this.rightText=rightText;
	}
	public String getRightText(){
		return rightText;
	}
	public void setRightUrl(String rightUrl){
	this.rightUrl=rightUrl;
	}
	public String getRightUrl(){
		return rightUrl;
	}
	public void setRightTip(String rightTip){
	this.rightTip=rightTip;
	}
	public String getRightTip(){
		return rightTip;
	}
}

