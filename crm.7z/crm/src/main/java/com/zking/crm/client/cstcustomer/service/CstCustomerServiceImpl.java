package com.zking.crm.client.cstcustomer.service;

import java.util.List;

import com.zking.crm.client.cstcustomer.dao.ICstCustomerDao;
import com.zking.crm.client.cstcustomer.model.CstCustomer;
import com.zking.crm.util.PageBean;


public class CstCustomerServiceImpl implements ICstCustomerService{

	private ICstCustomerDao cstCustomerDao;
	
	
	public ICstCustomerDao getCstCustomerDao() {
		return cstCustomerDao;
	}

	public void setCstCustomerDao(ICstCustomerDao cstCustomerDao) {
		this.cstCustomerDao = cstCustomerDao;
	}

	@Override
	public List<CstCustomer> getCstCustomers(CstCustomer customer) {
		// TODO Auto-generated method stub
		return cstCustomerDao.getCstCustomers(customer);
	}

	@Override
	public List<CstCustomer> getCstCustomersPage(CstCustomer customer, PageBean pageBean) {
		// TODO Auto-generated method stub
		return cstCustomerDao.getCstCustomersPage(customer, pageBean);
	}
	

	@Override
	public void addCstCustomer(CstCustomer customer) {
		// TODO Auto-generated method stub
		cstCustomerDao.addCstCustomer(customer);
	}

	@Override
	public void updateCstCustomer(CstCustomer customer) {
		// TODO Auto-generated method stub
		cstCustomerDao.updateCstCustomer(customer);
	}

	@Override
	public void delCstCustomer(CstCustomer customer) {
		// TODO Auto-generated method stub
		cstCustomerDao.delCstCustomer(customer);
	}

	@Override
	public CstCustomer selCstCustomer(CstCustomer customer) {
		// TODO Auto-generated method stub
		return cstCustomerDao.selCstCustomer(customer);
	}

	@Override
	public List<CstCustomer> listCstCustomer() {
		// TODO Auto-generated method stub
		return cstCustomerDao.listCstCustomer();
	}
	
	

}
