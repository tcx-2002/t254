package com.zking.crm.elsemarket.product.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.zking.crm.common.dao.BaseDao;
import com.zking.crm.elsemarket.product.model.Product;
import com.zking.crm.marketing.salplan.model.SalPlan;
import com.zking.crm.util.PageBean;

public class ProductDao extends BaseDao implements IProductDao{

	@Override
	public List<Product> listProduct(Product product, PageBean pageBean) {
		String hql = "select p from Product p where 1=1";
		Map<String,Object> params = new HashMap<>();
		if(product != null) {
			if(product.getProd_name()!=null&&!"".equals(product.getProd_name())) {
				hql += " and p.prod_name like :prod_name ";
				params.put("prod_name", "%"+product.getProd_name()+"%");
			}
			if(product.getProd_type()!=null&&!"".equals(product.getProd_type())) {
				hql+="and p.prod_type like :prod_type ";
				params.put("prod_type", "%"+product.getProd_type()+"%");
			}
			if(product.getProd_batch()!=null&&!"".equals(product.getProd_batch())) {
				hql+="and p.prod_batch like :prod_batch ";
				params.put("prod_batch", "%"+product.getProd_batch()+"%");
			}
		}
		
		List<Product> sal = this.query(hql, params, pageBean);
		return sal;
	}

	@Override
	public Product productByid(int prod_id) {
		// TODO Auto-generated method stub
		String hql = "select p from Product p where p.prod_id=? ";
		List<Product> list =(List<Product>) this.getHibernateTemplate().find(hql, prod_id);
		if(list.size()<1) {
			return null;
		}
		return list.get(0);
	}
	
	@Override
	public Product selProduct(Product product) {
		Product p = this.getHibernateTemplate().get(Product.class, product.getProd_id());
		return p;
	}

	@Override
	public List<Product> listProductName() {
		String hql = "select p from Product p";
		List<Product> list =(List<Product>) this.getHibernateTemplate().find(hql);
		return list;
	}


}
