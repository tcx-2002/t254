package com.zking.crm.client.cstlost.dao;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.zking.crm.client.cstlost.model.CstLost;
import com.zking.crm.common.dao.BaseDao;
import com.zking.crm.util.PageBean;


public class LostDaoImpl extends BaseDao implements ILostDao{

	
	@Override
	public List<CstLost> getCstLostPage(CstLost cstLost, PageBean pageBean) {
		String hql = "select b from CstLost b where 1=1 and b.lstStatus not in(3) ";
		Map<String,Object> params = new HashMap();
		
		if(cstLost != null && cstLost.getLstCustName()!= null && !"".equals(cstLost.getLstCustName())) {
			hql += " and b.lstCustName like :lstCustName";
			params.put("lstCustName", "%"+cstLost.getLstCustName()+"%");
		}
		if(cstLost != null && cstLost.getLstCustManagerName()!=null && !"".equals(cstLost.getLstCustManagerName())) {
			hql += " and b.lstCustManagerName like :lstCustManagerName";
			params.put("lstCustManagerName", "%"+cstLost.getLstCustManagerName()+"%");
		}
		if(cstLost != null && cstLost.getLstStatus()!=null && !"".equals(cstLost.getLstStatus())) {
			hql += " and b.lstStatus like :lstStatus";
			params.put("lstStatus", "%"+cstLost.getLstStatus()+"%");
		}
		
		List<CstLost> cstLosts = this.query(hql, params, pageBean);
		return cstLosts;
	}

	
	@Override
	public void updateLostStatus1(CstLost cstLost) {
		CstLost lost = this.getHibernateTemplate().get(CstLost.class, cstLost.getLstId());
		//预警时候，就是要暂缓流失了
		if(lost.getLstStatus()!=null&&!"".equals(lost.getLstStatus())) {
			String delay = lost.getLstDelay();
			
			lost.setLstId(cstLost.getLstId());
			lost.setLstCustNo(cstLost.getLstCustNo());
			lost.setLstCustName(cstLost.getLstCustName());
			lost.setLstCustManagerId(cstLost.getLstCustManagerId());
			lost.setLstCustManagerName(cstLost.getLstCustManagerName());
			lost.setLstLastOrderDate(cstLost.getLstLastOrderDate());
			lost.setLstLostDate(cstLost.getLstLostDate());
			lost.setLstReason(cstLost.getLstReason());
			lost.setLstStatus("20");
			lost.setLstDelay(cstLost.getLstDelay());
		}
		
	}
	@Override
	public void updateLostStatus2(CstLost cstLost) {
		// TODO Auto-generated method stub
		CstLost lost = this.getHibernateTemplate().get(CstLost.class, cstLost.getLstId());
		if(lost.getLstStatus()!=null&&!"".equals(lost.getLstStatus())) {
			lost.setLstId(cstLost.getLstId());
			lost.setLstCustNo(cstLost.getLstCustNo());
			lost.setLstCustName(cstLost.getLstCustName());
			lost.setLstCustManagerId(cstLost.getLstCustManagerId());
			lost.setLstCustManagerName(cstLost.getLstCustManagerName());
			lost.setLstLastOrderDate(cstLost.getLstLastOrderDate());
			lost.setLstLostDate(new Date());
			lost.setLstReason(cstLost.getLstReason());
			lost.setLstStatus("21");
			lost.setLstDelay(cstLost.getLstDelay());
		}
	}

	
	

}
