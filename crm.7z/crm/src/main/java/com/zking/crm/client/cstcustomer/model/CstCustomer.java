package com.zking.crm.client.cstcustomer.model;




public class CstCustomer{
	private String custNo;
	private String custName;
	private String custRegion;
	private long custManagerId;
	private String custManagerName;
	private int custLevel;
	private String custLevelLabel;
	private int custSatisfy;
	private int custCredit;
	private String custAddr;
	private String custZip;
	private String custTel;
	private String custFax;
	private String custWebsite;
	private String custLicenceNo;
	private String custChieftain;
	private long custBankroll;
	private long custTurnover;
	private String custBank;
	private String custBankAccount;
	private String custLocalTaxNo;
	private String custNationalTaxNo;
	private String custStatus;
	public void setCustNo(String custNo){
	this.custNo=custNo;
	}
	public String getCustNo(){
		return custNo;
	}
	public void setCustName(String custName){
	this.custName=custName;
	}
	public String getCustName(){
		return custName;
	}
	public void setCustRegion(String custRegion){
	this.custRegion=custRegion;
	}
	public String getCustRegion(){
		return custRegion;
	}
	public void setCustManagerId(long custManagerId){
	this.custManagerId=custManagerId;
	}
	public long getCustManagerId(){
		return custManagerId;
	}
	public void setCustManagerName(String custManagerName){
	this.custManagerName=custManagerName;
	}
	public String getCustManagerName(){
		return custManagerName;
	}
	public void setCustLevel(int custLevel){
	this.custLevel=custLevel;
	}
	public int getCustLevel(){
		return custLevel;
	}
	public void setCustLevelLabel(String custLevelLabel){
	this.custLevelLabel=custLevelLabel;
	}
	public String getCustLevelLabel(){
		return custLevelLabel;
	}
	public void setCustSatisfy(int custSatisfy){
	this.custSatisfy=custSatisfy;
	}
	public int getCustSatisfy(){
		return custSatisfy;
	}
	public void setCustCredit(int custCredit){
	this.custCredit=custCredit;
	}
	public int getCustCredit(){
		return custCredit;
	}
	public void setCustAddr(String custAddr){
	this.custAddr=custAddr;
	}
	public String getCustAddr(){
		return custAddr;
	}
	public void setCustZip(String custZip){
	this.custZip=custZip;
	}
	public String getCustZip(){
		return custZip;
	}
	public void setCustTel(String custTel){
	this.custTel=custTel;
	}
	public String getCustTel(){
		return custTel;
	}
	public void setCustFax(String custFax){
	this.custFax=custFax;
	}
	public String getCustFax(){
		return custFax;
	}
	public void setCustWebsite(String custWebsite){
	this.custWebsite=custWebsite;
	}
	public String getCustWebsite(){
		return custWebsite;
	}
	public void setCustLicenceNo(String custLicenceNo){
	this.custLicenceNo=custLicenceNo;
	}
	public String getCustLicenceNo(){
		return custLicenceNo;
	}
	public void setCustChieftain(String custChieftain){
	this.custChieftain=custChieftain;
	}
	public String getCustChieftain(){
		return custChieftain;
	}
	public void setCustBankroll(long custBankroll){
	this.custBankroll=custBankroll;
	}
	public long getCustBankroll(){
		return custBankroll;
	}
	public void setCustTurnover(long custTurnover){
	this.custTurnover=custTurnover;
	}
	public long getCustTurnover(){
		return custTurnover;
	}
	public void setCustBank(String custBank){
	this.custBank=custBank;
	}
	public String getCustBank(){
		return custBank;
	}
	public void setCustBankAccount(String custBankAccount){
	this.custBankAccount=custBankAccount;
	}
	public String getCustBankAccount(){
		return custBankAccount;
	}
	public void setCustLocalTaxNo(String custLocalTaxNo){
	this.custLocalTaxNo=custLocalTaxNo;
	}
	public String getCustLocalTaxNo(){
		return custLocalTaxNo;
	}
	public void setCustNationalTaxNo(String custNationalTaxNo){
	this.custNationalTaxNo=custNationalTaxNo;
	}
	public String getCustNationalTaxNo(){
		return custNationalTaxNo;
	}
	public void setCustStatus(String custStatus){
	this.custStatus=custStatus;
	}
	public String getCustStatus(){
		return custStatus;
	}
}

