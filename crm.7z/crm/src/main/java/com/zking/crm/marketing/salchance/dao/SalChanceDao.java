package com.zking.crm.marketing.salchance.dao;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.zking.crm.common.dao.BaseDao;
import com.zking.crm.marketing.salchance.model.SalChance;
import com.zking.crm.util.PageBean;

public class SalChanceDao extends BaseDao implements ISalChanceDao{

	@Override
	public List<SalChance> SalChanceList(SalChance salchance,PageBean pagebean) {
//		String hql = "select s from SalChance s";
//		List<SalChance> list = (List<SalChance>)this.getHibernateTemplate().find(hql);
//		return list;
		String hql = "select s from SalChance s where 1=1 and s.chcStatus=:chcStatus";
		Map<String,Object> params = new HashMap<>();
		params.put("chcStatus",salchance.getChcStatus());
		if(salchance != null 
				&& salchance.getChcCustName()!=null 
				&& !"".equals(salchance.getChcCustName())) {
			hql += " and s.chcCustName like :chcCustName";
			params.put("chcCustName", "%"+salchance.getChcCustName()+"%");
		}
		
		List<SalChance> sal = this.query(hql, params, pagebean);
		return sal;
	}

	@Override
	public Integer addSalChance(SalChance salchance) {
		Serializable Serializable = this.getHibernateTemplate().save(salchance);
		return Integer.parseInt(Serializable.toString());
	}

	/**
	 * 2020/11/26 02:23
	 * 错误 已解决
	 * A different object with the same identifier value was already associated with the session : [com.zking.crm.marketing.salchance.model.SalChance#6]; nested exception is org.hibernate.NonUniqueObjectException: A different object with the same identifier value was already associated with the session : [com.zking.crm.marketing.salchance.model.SalChance#6]
	 * 
	 */
	@Override
	public void updateSalChance(SalChance salchance) {
		//先查询出要修改的信息在数据库是否存在
		SalChance sal = this.getHibernateTemplate().get(SalChance.class, salchance.getChcId());
		//如果存在才进行修改操作
		if(sal!=null) {
//			sal = new SalChance(sal.getChcId(),salchance.getChcSource(), salchance.getChcCustName(), salchance.getChcTitle(), salchance.getChcRate(), salchance.getChcLinkman(),salchance.getChcTel(),salchance.getChcDesc(),salchance.getChcCreateId(), salchance.getChcCreateBy(), salchance.getChcCreateDate(), salchance.getChcDueId(), salchance.getChcDueTo(), salchance.getChcDueDate(), salchance.getChcStatus());
//			this.getHibernateTemplate().update(sal);
			sal.setChcSource(salchance.getChcSource());
			sal.setChcCustName(salchance.getChcCustName());
			sal.setChcTitle(salchance.getChcTitle());
			sal.setChcRate(salchance.getChcRate());
			sal.setChcLinkman(salchance.getChcLinkman());
			sal.setChcTel(salchance.getChcTel());
			sal.setChcDesc(salchance.getChcDesc());
			sal.setChcCreateId(salchance.getChcCreateId());
			sal.setChcCreateBy(salchance.getChcCreateBy());
			sal.setChcCreateDate(salchance.getChcCreateDate());
			sal.setChcDueId(salchance.getChcDueId());
			sal.setChcDueTo(salchance.getChcDueTo());
			sal.setChcDueDate(salchance.getChcDueDate());
			sal.setChcStatus(salchance.getChcStatus());
		}
//		System.out.println(salchance);
//		this.getHibernateTemplate().update(salchance);
	}

	@Override
	public void deleteSalChance(long chcId) {
		//先查询出要修改的信息在数据库是否存在
		SalChance sal = this.getHibernateTemplate().get(SalChance.class, chcId);
		if(sal!=null) {
			this.getHibernateTemplate().delete(sal);
		}
	}

	@Override
	public SalChance salChanceById(long chcId) {
		String hql = "select s from SalChance s where s.chcId=?";
		List<SalChance> list = (List<SalChance>) this.getHibernateTemplate().find(hql, chcId);
		if(list.size()<1) {
	    	return null;
	    }
	    return list.get(0);
	}

}
