package com.zking.crm.jurisdiction.module.action;

import java.util.List;

import com.zking.crm.common.action.BaseAction;
import com.zking.crm.jurisdiction.module.model.Module;
import com.zking.crm.jurisdiction.module.service.IModuleService;


public class SysMsgAction extends BaseAction {
	
	private IModuleService moduleService;
	
	public IModuleService getModuleService() {
		return moduleService;
	}

	public void setModuleService(IModuleService moduleService) {
		this.moduleService = moduleService;
	}

	public void getModules() {
		
		List<Module> datas = moduleService.getModules();
		
		this.writeAsJson(datas);
		
	}


}
