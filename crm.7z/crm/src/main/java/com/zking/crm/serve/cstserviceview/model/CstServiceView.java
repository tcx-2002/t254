package com.zking.crm.serve.cstserviceview.model;

public class CstServiceView {
private Integer cid;
private String citem;
private String cdate;
private Integer count;
public Integer getCid() {
	return cid;
}

public Integer getCount() {
	return count;
}

public void setCount(Integer count) {
	this.count = count;
}

public void setCid(Integer cid) {
	this.cid = cid;
}
public String getCitem() {
	return citem;
}
public void setCitem(String citem) {
	this.citem = citem;
}
public String getCdate() {
	return cdate;
}
public void setCdate(String cdate) {
	this.cdate = cdate;
}
@Override
public String toString() {
	return "CstServiceView [cid=" + cid + ", citem=" + citem + ", cdate=" + cdate + "]";
}



}
