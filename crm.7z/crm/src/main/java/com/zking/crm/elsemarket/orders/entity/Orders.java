package com.zking.crm.elsemarket.orders.entity;
import java.util.Date;
   /**
    * orders 实体类
    * Sun Nov 29 12:48:23 CST 2020 bkx
    */ 


public class Orders{
	private int odr_id;
	private int odr_custno;
	private String odr_custname;
	private Date odr_date;
	private String odr_addr;
	private String odr_status;
	public void setOdr_id(int odr_id){
	this.odr_id=odr_id;
	}
	public int getOdr_id(){
		return odr_id;
	}
	public void setOdr_custno(int odr_custno){
	this.odr_custno=odr_custno;
	}
	public int getOdr_custno(){
		return odr_custno;
	}
	public void setOdr_custname(String odr_custname){
	this.odr_custname=odr_custname;
	}
	public String getOdr_custname(){
		return odr_custname;
	}
	public void setOdr_date(Date odr_date){
	this.odr_date=odr_date;
	}
	public Date getOdr_date(){
		return odr_date;
	}
	public void setOdr_addr(String odr_addr){
	this.odr_addr=odr_addr;
	}
	public String getOdr_addr(){
		return odr_addr;
	}
	public void setOdr_status(String odr_status){
	this.odr_status=odr_status;
	}
	public String getOdr_status(){
		return odr_status;
	}
	@Override
	public String toString() {
		return "Orders [odr_id=" + odr_id + ", odr_custno=" + odr_custno + ", odr_custname=" + odr_custname
				+ ", odr_date=" + odr_date + ", odr_addr=" + odr_addr + ", odr_status=" + odr_status + "]";
	}
	
	
}

