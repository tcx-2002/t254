package com.zking.crm.elsemarket.storage.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.zking.crm.common.dao.BaseDao;
import com.zking.crm.elsemarket.product.model.Product;
import com.zking.crm.elsemarket.storage.model.Storage;
import com.zking.crm.util.PageBean;

public class StorageDao extends BaseDao implements IStorageDao{

	@Override
	public List<Storage> listStorage(Storage storage, PageBean pageBean) {
		String hql = "select s from Storage s where 1=1";
		Map<String,Object> params = new HashMap<>();
		if(storage != null) {
			if(storage.getStk_prod_name()!=null&&!"".equals(storage.getStk_prod_name())) {
				hql+="and s.stk_prod_name like :stk_prod_name ";
				params.put("stk_prod_name", "%"+storage.getStk_prod_name()+"%");
			}
			if(storage.getStk_warehouse()!=null&&!"".equals(storage.getStk_warehouse())) {
				hql+="and s.stk_warehouse like :stk_warehouse ";
				params.put("stk_warehouse", "%"+storage.getStk_warehouse()+"%");
			}
		}
		List<Storage> sal = this.query(hql, params, pageBean);
		return sal;
	}

}
