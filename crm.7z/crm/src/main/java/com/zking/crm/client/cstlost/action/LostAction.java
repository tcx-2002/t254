package com.zking.crm.client.cstlost.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ModelDriven;
import com.zking.crm.client.cstlost.model.CstLost;
import com.zking.crm.client.cstlost.service.ILostService;
import com.zking.crm.common.action.BaseAction;
import com.zking.crm.util.PageBean;

public class LostAction extends BaseAction implements ModelDriven<CstLost>{

	private CstLost Lost = new CstLost();
	
	@Override
	public CstLost getModel() {
		// TODO Auto-generated method stub
		return Lost;
	}
	
	
	private ILostService lostService;

	public ILostService getLostService() {
		return lostService;
	}


	public void setLostService(ILostService lostService) {
		this.lostService = lostService;
	}
	
	public void getCstCustomers() {
		PageBean pageBean = new PageBean();
		pageBean.setRequest(ServletActionContext.getRequest());
		
		List<CstLost> cstLosts = lostService.getCstLostPage(Lost, pageBean);
		Map<String, Object> data = new HashMap<String, Object>();
		data.put("total", pageBean.getTotal());
		data.put("totalPageNum", pageBean.getTotalPageNum());
		data.put("page", pageBean.getPage());
		data.put("rows", pageBean.getRows());
		data.put("data", cstLosts);
		this.writeAsJson(data);
	}
	
	
	
	/**
	 * 修改书本信息
	 */
	public void updateCstLost1() {
		Map<String, Object> map = new HashMap<>();
		try {
			lostService.updateLostStatus1(this.Lost);
			map.put("success", true);
			map.put("msg", "操作成功");
		} catch (Exception e) {
			map.put("success", false);
			map.put("msg", "操作失败");
		}
		this.writeAsJson(map);
	}


	public void updateCstLost2() {
		Map<String, Object> map = new HashMap<>();
		try {
			lostService.updateLostStatus2(this.Lost);
			map.put("success", true);
			map.put("msg", "操作成功");
		} catch (Exception e) {
			map.put("success", false);
			map.put("msg", "操作失败");
		}
		this.writeAsJson(map);
	}
}
