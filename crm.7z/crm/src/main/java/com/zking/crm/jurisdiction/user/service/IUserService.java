package com.zking.crm.jurisdiction.user.service;

import java.util.List;

import com.zking.crm.jurisdiction.user.model.User;

public interface IUserService {
	/**
	 * 登录的方法
	 * 
	 * @param user
	 *            要进行验证的信息
	 * @return 验证是否通过
	 */
	User login(User user);

	/**
	 * 增加系统角色的方法
	 * 
	 * @param user
	 *           要增加的角色信息
	 * @return 是否增加成功
	 */
	Integer addUser(User user);
	/**
	 * 查询出为客户经理的系统用户
	 */
	List<User> userAM();
	/**
	 * 通过id查询对应的系统用户
	 * @return
	 */
	User userById(Integer usrId);
	/**
	 * 查找客户经理
	 */
	public List<User> selCustManagerName();


}
