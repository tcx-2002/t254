package com.zking.crm.client.contribute.model;

import java.math.BigDecimal;

public class Contribute {
	private Integer ctb_id;
	
	private String ctb_name;
	
	private String ctb_time;
	
	private BigDecimal ctb_momney;

	public Integer getCtb_id() {
		return ctb_id;
	}

	public void setCtb_id(Integer ctb_id) {
		this.ctb_id = ctb_id;
	}

	public String getCtb_name() {
		return ctb_name;
	}

	public void setCtb_name(String ctb_name) {
		this.ctb_name = ctb_name;
	}

	public String getCtb_time() {
		return ctb_time;
	}

	public void setCtb_time(String ctb_time) {
		this.ctb_time = ctb_time;
	}

	public BigDecimal getCtb_momney() {
		return ctb_momney;
	}

	public void setCtb_momney(BigDecimal ctb_momney) {
		this.ctb_momney = ctb_momney;
	}

	@Override
	public String toString() {
		return "Contribute [ctb_id=" + ctb_id + ", ctb_name=" + ctb_name + ", ctb_time=" + ctb_time + ", ctb_momney="
				+ ctb_momney + "]";
	}
	
	
	
	
	
	
}
