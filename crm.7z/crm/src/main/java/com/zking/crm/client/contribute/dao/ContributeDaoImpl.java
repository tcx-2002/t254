package com.zking.crm.client.contribute.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.zking.crm.client.contribute.model.Contribute;
import com.zking.crm.common.dao.BaseDao;
import com.zking.crm.util.PageBean;

public class ContributeDaoImpl extends BaseDao implements IContributeDao{

	@Override
	public List<Contribute> listContribute(Contribute contribute, PageBean pageBean) {
		String hql = "select c from Contribute c where 1=1";
		Map<String,Object> params = new HashMap<>();
		if(contribute != null) {
			if(contribute.getCtb_name()!=null&&!"".equals(contribute.getCtb_name())) {
				hql += " and c.ctb_name like :ctb_name ";
				params.put("ctb_name", "%"+contribute.getCtb_name()+"%");
			}
			if(contribute.getCtb_time()!=null&&!"".equals(contribute.getCtb_time())) {
				hql+="and c.ctb_time = :ctb_time ";
				params.put("ctb_time", contribute.getCtb_time());
			}
		}
		List<Contribute> sal = this.query(hql, params, pageBean);
		return sal;
	}

	@Override
	public List<Contribute> listCdate() {
		String hql = "select c.ctb_time from Contribute c group by c.ctb_time";
		List<Contribute> find =(List<Contribute>) this.getHibernateTemplate().find(hql);
		return find;
	}

}
