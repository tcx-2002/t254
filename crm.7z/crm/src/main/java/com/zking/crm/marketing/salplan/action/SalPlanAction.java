package com.zking.crm.marketing.salplan.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.opensymphony.xwork2.ModelDriven;
import com.zking.crm.common.action.BaseAction;
import com.zking.crm.marketing.salplan.model.SalPlan;
import com.zking.crm.marketing.salplan.service.ISalPlanService;

public class SalPlanAction extends BaseAction implements ModelDriven<SalPlan> {
	private SalPlan salPlan = new SalPlan();

	@Override
	public SalPlan getModel() {
		// TODO Auto-generated method stub
		return salPlan;
	}

	private ISalPlanService salPlanService;

	public ISalPlanService getSalPlanService() {
		return salPlanService;
	}

	public void setSalPlanService(ISalPlanService salPlanService) {
		this.salPlanService = salPlanService;
	}

	public void salPlanByPlaChcId() {
		Map<String, Object> map = new HashMap<>();
		List<SalPlan> plas = salPlanService.salPlanByChcId(salPlan.getPlaChcId());
		map.put("salPlan", plas);
		this.writeAsJson(map);
	}

	/**
	 * 11/27 17:00 问题 Write operations are not allowed in read-only mode
	 * (FlushMode.MANUAL): Turn your Session into FlushMode.COMMIT/AUTO or remove
	 * 'readOnly' marker from transaction definition.
	 * 
	 * 已解决 问题是因为Dao跟service没有按照环绕通知的命名规范所定义
	 */
	public void salPlanAdd() {
		Map<String, Object> map = new HashMap<>();
		System.out.println(salPlan);
		Integer n = salPlanService.addSalPlan(salPlan);
		System.out.println(n);
		if (n > 0) {
			map.put("success", true);
			map.put("msg", "增加成功");
		} else {
			map.put("success", false);
			map.put("msg", "增加失败");
		}
		this.writeAsJson(map);
	}

	public void salPlanDelete() {
		Map<String, Object> map = new HashMap<>();
		System.out.println(salPlan.getPlaId());
		try {
			salPlanService.deleteSalPlan(salPlan.getPlaId());
			map.put("success", true);
			map.put("msg", "删除成功");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			map.put("success", false);
			map.put("msg", "删除失败");
		}
		this.writeAsJson(map);
	}

	public void salPlanUpdate() {
		System.out.println(salPlan);
		Map<String, Object> map = new HashMap<>();
		try {
			salPlanService.updateSalPlan(salPlan);
			map.put("success", true);
			map.put("msg", "修改成功");
		} catch (Exception e) {
			map.put("success", false);
			map.put("msg", "修改失败");
		}
		this.writeAsJson(map);
	}
}
