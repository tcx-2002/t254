package com.zking.crm.serve.cstservice.dao;

import java.util.List;

import com.zking.crm.serve.cstservice.model.CstService;
import com.zking.crm.serve.cstserviceview.model.CstServiceView;
import com.zking.crm.util.PageBean;

public interface ICstServiceDao {
	/**
	 * 查询的方法
	 * 
	 * @param cstService
	 * @param pagebean
	 * @return
	 */
	List<CstService> listCstService(CstService cstService, PageBean pagebean);

	/**
	 * 增加的方法
	 * 
	 * @param cstService
	 * @return
	 */
	Integer addCstService(CstService cstService);

	/**
	 * 删除的方法
	 * 
	 * @param svrId
	 */
	void deleteCstService(long svrId);

	/**
	 * 修改的方法
	 * 
	 * @param cstService
	 */
	void updateCtsService(CstService cstService);
	
	
}
