package com.zking.crm.statistics.stituexydview.dao;

import java.util.List;

import com.zking.crm.statistics.stituexydview.model.StitueXydView;

public interface IStitueXydViewDao {
List<StitueXydView> listStitue();
}
