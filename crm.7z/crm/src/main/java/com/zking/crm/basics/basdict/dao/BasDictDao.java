package com.zking.crm.basics.basdict.dao;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.zking.crm.basics.basdict.model.BasDict;
import com.zking.crm.common.dao.BaseDao;
import com.zking.crm.marketing.salplan.model.SalPlan;
import com.zking.crm.util.PageBean;

public class BasDictDao extends BaseDao implements IBasDictDao{

	@Override
	public List<BasDict> listBasDict(BasDict basDict, PageBean pageBean) {
		String hql = "select b from BasDict b where 1=1";
		Map<String,Object> params = new HashMap<>();
		if(basDict != null 
				&& basDict.getDictValue()!=null 
				&& !"".equals(basDict.getDictValue())) {
			hql += " and b."+basDict.getType()+" like :"+basDict.getType()+"";
			params.put(""+basDict.getType()+"", "%"+basDict.getDictValue()+"%");
		}
		
		List<BasDict> sal = this.query(hql, params, pageBean);
		return sal;
	}

	@Override
	public Integer addBasDict(BasDict basDict) {
		Serializable ser = this.getHibernateTemplate().save(basDict);
		return Integer.parseInt(ser.toString());
	}

	@Override
	public void updateBasDict(BasDict basDict) {
		BasDict bas = this.getHibernateTemplate().get(BasDict.class, basDict.getDictID());
		if(bas!=null) {
			bas.setDictTypr(basDict.getDictTypr());
			bas.setType(basDict.getType());
			bas.setDictItem(basDict.getDictItem());
			bas.setDictValue(basDict.getDictValue());
			bas.setDictIsEditable(basDict.getDictIsEditable());
		}
	}

	@Override
	public void deleteBasDict(int dictID) {
		BasDict bas = this.getHibernateTemplate().get(BasDict.class, dictID);
		if(bas!=null) {
			this.getHibernateTemplate().delete(bas);
		}
	}

	@Override
	public void deleteBasDictByItem(String dictItem) {
		String hql = "delete b from BasDict b where b.dictItem=?";
		this.getHibernateTemplate().find(hql, dictItem);
	}

	@Override
	public List<BasDict> basDictByDictItem(String dictItem) {
		// TODO Auto-generated method stub
		String hql = "select b from BasDict b where b.dictItem=?";
		List<BasDict> basDicts =(List<BasDict>) this.getHibernateTemplate().find(hql, new String[] {dictItem});
		return basDicts;
	}

	@Override
	public BasDict basDictById(int dictID) {
		String hql = "select b from BasDict b where b.dictID=?";
		List<BasDict> list =(List<BasDict>) this.getHibernateTemplate().find(hql,dictID);
		if(list.size()<1) {
	    	return null;
	    }
	    return list.get(0);
	}
	@Override
	public List<BasDict> selCustAddrs(String dictItem){
		String hql = "from BasDict b where b.dictItem = ?";
		List<BasDict> list = (List<BasDict>) this.getHibernateTemplate().find(hql, dictItem);
		return list;
	}

	@Override
	public List<BasDict> selCustManagerName(String dictItem) {
		String hql = "from BasDict b where b.dictItem = ?";
		List<BasDict> list = (List<BasDict>) this.getHibernateTemplate().find(hql, dictItem);
		return list;
	}

	@Override
	public List<BasDict> selCustSatisfy(String dictItem) {
		String hql = "from BasDict b where b.dictItem = ?";
		List<BasDict> list = (List<BasDict>) this.getHibernateTemplate().find(hql, dictItem);
		return list;
	}

	@Override
	public List<BasDict> selCustLevelLabel(String dictItem) {
		String hql = "from BasDict b where b.dictItem = ?";
		List<BasDict> list = (List<BasDict>) this.getHibernateTemplate().find(hql, dictItem);
		return list;
	}

	@Override
	public List<BasDict> selCustCredit(String dictItem) {
		String hql = "from BasDict b where b.dictItem = ?";
		List<BasDict> list = (List<BasDict>) this.getHibernateTemplate().find(hql, dictItem);
		return list;
	}

	@Override
	public BasDict selCstCustomerLevel(Integer dictID) {
		String hql = "from BasDict b where b.dictID = ?";
		List<BasDict> list = (List<BasDict>) this.getHibernateTemplate().find(hql, dictID);
		if(list.size() > 0) {
			return list.get(0);
		}else {
			return null;
		}
	}
	
	

}
