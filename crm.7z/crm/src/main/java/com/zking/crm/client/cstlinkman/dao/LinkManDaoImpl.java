package com.zking.crm.client.cstlinkman.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.zking.crm.client.cstlinkman.model.CstLinkman;
import com.zking.crm.common.dao.BaseDao;
import com.zking.crm.util.PageBean;


public class LinkManDaoImpl extends BaseDao implements ILinkManDao{

	@Override
	public List<CstLinkman> selCstLinkman(String lkmCustNo) {
		String hql ="from CstLinkman c where c.lkmCustNo = ?";
		List<CstLinkman> list = (List<CstLinkman>) this.getHibernateTemplate().find(hql, lkmCustNo);
		if(list.size()>0) {
			return list;
		}
		return null;
	}

	@Override
	public List<CstLinkman> getCstLinkmanPage(CstLinkman linkMan, PageBean pageBean) {
		String hql = "select b from CstLinkman b where 1=1";
		Map<String,Object> params = new HashMap();
		if(linkMan != null && linkMan.getLkmCustNo() != null && !"".equals(linkMan.getLkmCustNo())) {
			hql += " and b.lkmCustNo like :lkmCustNo";
			params.put("lkmCustNo", "%"+linkMan.getLkmCustNo()+"%");
		}
		if(linkMan != null && linkMan.getLkmCustName()!=null && !"".equals(linkMan.getLkmCustName())) {
			hql += " and b.lkmCustName like :lkmCustName";
			params.put("lkmCustName", "%"+linkMan.getLkmCustName()+"%");
		}
		
		List<CstLinkman> linkMans = this.query(hql, params, pageBean);
		return linkMans;
	}

	@Override
	public void addCstLinkman(CstLinkman linkMan) {
		// TODO Auto-generated method stub
		this.getHibernateTemplate().save(linkMan);
	}

	@Override
	public void updateCstLinkman(CstLinkman linkMan) {
		// TODO Auto-generated method stub
		CstLinkman link = this.getHibernateTemplate().get(CstLinkman.class, linkMan.getLkmId());
		if(link != null) {
			link.setLkmName(linkMan.getLkmName());
			link.setLkmSex(linkMan.getLkmSex());
			link.setLkmPostion(linkMan.getLkmPostion());
			link.setLkmTel(linkMan.getLkmTel());
			link.setLkmMobile(linkMan.getLkmMobile());
			link.setLkmMemo(linkMan.getLkmMemo());
		}
	}

	@Override
	public void delCstLinkman(CstLinkman linkMan) {
		// TODO Auto-generated method stub
		CstLinkman link = this.getHibernateTemplate().get(CstLinkman.class,linkMan.getLkmId());
		if(link != null) {
			this.getHibernateTemplate().delete(link);
		}
	}
	

}
