package com.zking.crm.serve.cstservice.dao;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.NativeQuery;

import com.zking.crm.basics.basdict.model.BasDict;
import com.zking.crm.common.dao.BaseDao;
import com.zking.crm.serve.cstservice.model.CstService;
import com.zking.crm.serve.cstserviceview.model.CstServiceView;
import com.zking.crm.util.PageBean;

public class CstServiceDao extends BaseDao implements ICstServiceDao {

	@SuppressWarnings("unchecked")
	@Override
	public List<CstService> listCstService(CstService cstService, PageBean pagebean) {
		String hql = "select c from CstService c where 1=1 ";
		Map<String, Object> params = new HashMap<>();
		if (cstService != null) {
			if (cstService.getSvrStatus() != null && !"".equals(cstService.getSvrStatus())) {
				hql += "and c.svrStatus=:svrStatus ";
				params.put("svrStatus", cstService.getSvrStatus());
			}
			if (cstService.getSvrCustName() != null && !"".equals(cstService.getSvrCustName())) {
				hql += " and c.svrCustName like :svrCustName ";
				params.put("svrCustName", "%" + cstService.getSvrCustName() + "%");
			}
			if (cstService.getSvrTitle() != null && !"".equals(cstService.getSvrTitle())) {
				hql += "and c.svrTitle like :svrTitle ";
				params.put("svrTitle", "%" + cstService.getSvrTitle() + "%");
			}
			if (cstService.getSvrType() != null && !"".equals(cstService.getSvrType())) {
				hql += "and c.svrType like :svrType ";
				params.put("svrType", "%" + cstService.getSvrType() + "%");
			}
			if (cstService.getSvrCreateDate() != null && !"".equals(cstService.getSvrCreateDate())) {
				hql += "and c.svrDealDate like :svrDealDate ";
				params.put("svrDealDate", "%" + cstService.getSvrDealDate() + "%");
			}
		}
		List<CstService> sal = this.query(hql, params, pagebean);
		return sal;
	}

	@Override
	public Integer addCstService(CstService cstService) {
		Serializable ser = this.getHibernateTemplate().save(cstService);
		return Integer.parseInt(ser.toString());
	}

	@Override
	public void deleteCstService(long svrId) {
		CstService cst = this.getHibernateTemplate().get(CstService.class, svrId);
		if (cst != null) {
			this.getHibernateTemplate().delete(cst);
		}
	}

	@Override
	public void updateCtsService(CstService cstService) {
		CstService cst = this.getHibernateTemplate().get(CstService.class, cstService.getSvrId());
		if (cst != null) {
			cst.setSvrType(cstService.getSvrType());
			cst.setSvrTitle(cstService.getSvrTitle());
			cst.setSvrCustNo(cstService.getSvrCustNo());
			cst.setSvrCustName(cstService.getSvrCustName());
			cst.setSvrStatus(cstService.getSvrStatus());
			cst.setSvrRequest(cstService.getSvrRequest());
			cst.setSvrCreateId(cstService.getSvrCreateId());
			cst.setSvrCreateBy(cstService.getSvrCreateBy());
			cst.setSvrCreateDate(cstService.getSvrCreateDate());
			cst.setSvrDueId(cstService.getSvrDueId());
			cst.setSvrDueTo(cstService.getSvrDueTo());
			cst.setSvrDueDate(cstService.getSvrDueDate());
			cst.setSvrDeal(cstService.getSvrDeal());
			cst.setSvrDealId(cstService.getSvrDealId());
			cst.setSvrDealBy(cstService.getSvrDealBy());
			cst.setSvrDealDate(cstService.getSvrDealDate());
			cst.setSvrResult(cstService.getSvrResult());
			cst.setSvrSatisfy(cstService.getSvrSatisfy());

		}

	}

}
