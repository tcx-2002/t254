package com.zking.crm.client.cstlinkman.service;

import java.util.List;

import com.zking.crm.client.cstlinkman.model.CstLinkman;
import com.zking.crm.util.PageBean;

public interface ILinkManService {

	/**
	 * 查询联系人
	 * @param custNo
	 * @return
	 */
	public List<CstLinkman> selCstLinkman(String lkmCustNo);
	
	
	public List<CstLinkman> getCstLinkmanPage(CstLinkman linkMan,PageBean pageBean);

	public void addCstLinkman(CstLinkman linkMan);
	
	public void updateCstLinkman(CstLinkman linkMan);
	
	public void delCstLinkman(CstLinkman linkMan);
}
