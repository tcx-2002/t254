package com.zking.crm.client.cstactivity.model;


import java.util.Date;


public class CstActivity{
	private long atvId;
	private String atvCustNo;
	private String atvCustName;
	private Date atvDate;
	private String atvPlace;
	private String atvTitle;
	private String atvRemark;
	private String atvDesc;
	public void setAtvId(long atvId){
	this.atvId=atvId;
	}
	public long getAtvId(){
		return atvId;
	}
	public void setAtvCustNo(String atvCustNo){
	this.atvCustNo=atvCustNo;
	}
	public String getAtvCustNo(){
		return atvCustNo;
	}
	public void setAtvCustName(String atvCustName){
	this.atvCustName=atvCustName;
	}
	public String getAtvCustName(){
		return atvCustName;
	}
	public void setAtvDate(Date atvDate){
	this.atvDate=atvDate;
	}
	public Date getAtvDate(){
		return atvDate;
	}
	public void setAtvPlace(String atvPlace){
	this.atvPlace=atvPlace;
	}
	public String getAtvPlace(){
		return atvPlace;
	}
	public void setAtvTitle(String atvTitle){
	this.atvTitle=atvTitle;
	}
	public String getAtvTitle(){
		return atvTitle;
	}
	public void setAtvRemark(String atvRemark){
	this.atvRemark=atvRemark;
	}
	public String getAtvRemark(){
		return atvRemark;
	}
	public void setAtvDesc(String atvDesc){
	this.atvDesc=atvDesc;
	}
	public String getAtvDesc(){
		return atvDesc;
	}
}

