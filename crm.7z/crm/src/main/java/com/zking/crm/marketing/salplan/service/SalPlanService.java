package com.zking.crm.marketing.salplan.service;

import java.util.List;

import com.zking.crm.marketing.salplan.dao.ISalPlanDao;
import com.zking.crm.marketing.salplan.model.SalPlan;
import com.zking.crm.util.PageBean;

public class SalPlanService implements ISalPlanService{
private ISalPlanDao salPlanDao;

public ISalPlanDao getSalPlanDao() {
	return salPlanDao;
}

public void setSalPlanDao(ISalPlanDao salPlanDao) {
	this.salPlanDao = salPlanDao;
}

@Override
public List<SalPlan> salPlanList(SalPlan salPlan, PageBean pageBean) {
	// TODO Auto-generated method stub
	return salPlanDao.salPlanList(salPlan, pageBean);
}

@Override
public Integer addSalPlan(SalPlan salPlan) {
	// TODO Auto-generated method stub
	return salPlanDao.addSalPlan(salPlan);
}

@Override
public void updateSalPlan(SalPlan salPlan) {
	salPlanDao.updateSalPlan(salPlan);
}

@Override
public void deleteSalPlan(long plaId) {
	// TODO Auto-generated method stub
	salPlanDao.deleteSalPlan(plaId);
	
}

@Override
public List<SalPlan> salPlanByChcId(long plaChcId) {
	// TODO Auto-generated method stub
	return salPlanDao.salPlanByChcId(plaChcId);
}


}
