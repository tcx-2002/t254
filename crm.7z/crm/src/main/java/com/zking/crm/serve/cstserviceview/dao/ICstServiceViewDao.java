package com.zking.crm.serve.cstserviceview.dao;

import java.util.List;

import com.zking.crm.serve.cstserviceview.model.CstServiceView;

public interface ICstServiceViewDao {
/**
 * 通过年份查询服务统计
 * @param cstServiceView
 * @return
 */
List<CstServiceView> listCstServiceView(CstServiceView cstServiceView);
/**
 * 查询所有年份
 * @return
 */
List<CstServiceView> listCdate();
/**
 * 增加数量
 * @param count
 */
void addCount(CstServiceView cstServiceView);

///**
// * 查询所有年份的日期
// * @param options
// * @return
// */
//List<List<CstServiceView>> listServiceView(String[] options);
/**
 * 查询cdate年份的统计
 * @return
 */
List<CstServiceView> listServiceView(Integer cdate);

/**
 * 查询给定的日期跟后面五年的年份
 * @param cdate 给定的日期
 * @return
 */
List<CstServiceView> listCdate(Integer cdate);
}
