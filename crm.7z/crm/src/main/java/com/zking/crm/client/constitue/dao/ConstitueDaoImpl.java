package com.zking.crm.client.constitue.dao;

import java.util.List;

import com.zking.crm.client.constitue.model.Constitue;
import com.zking.crm.common.dao.BaseDao;

public class ConstitueDaoImpl extends BaseDao implements IConstitueDao{

	@Override
	public List<Constitue> listConstitue(Constitue constitue) {
		String hql = "select c from Constitue c where c.cte_type=?";
		List<Constitue> list =(List<Constitue>)this.getHibernateTemplate().find(hql, constitue.getCte_type());
		return list;
	}

	@Override
	public List<Constitue> listType() {
		String hql = "select c.cte_type from Constitue c group by c.cte_type";
		List<Constitue> list =(List<Constitue>) this.getHibernateTemplate().find(hql);
		return list;
	}

}
