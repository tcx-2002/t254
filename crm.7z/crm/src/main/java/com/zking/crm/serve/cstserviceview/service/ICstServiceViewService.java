package com.zking.crm.serve.cstserviceview.service;

import java.util.List;

import com.zking.crm.serve.cstserviceview.model.CstServiceView;

public interface ICstServiceViewService {
	List<CstServiceView> listCstServiceView(CstServiceView cstServiceView);
	/**
	 * 查询所有年份
	 * @return
	 */
	List<CstServiceView> listCdate();
	/**
	 * 增加数量
	 * @param count
	 */
	void addCount(CstServiceView cstServiceView);
//	/**
//	 * 查询所有年份的日期
//	 * @param options
//	 * @return
//	 */
//	List<List<CstServiceView>> listServiceView(String[] options);
	/**
	 * 查询cdate年份的统计
	 * @return
	 */
	List<CstServiceView> listServiceView(Integer cdate);
	/**
	 * 查询给定的日期跟后面五年的年份
	 * @param cdate 给定的日期
	 * @return
	 */
	List<CstServiceView> listCdate(Integer cdate);
}
