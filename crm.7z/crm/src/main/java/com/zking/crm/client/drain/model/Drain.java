package com.zking.crm.client.drain.model;

public class Drain {
	private Integer drn_id;
	
	private String drn_date;
	
	private String drn_name;
	
	private String drn_manager;
	
	private String drn_yuanyin;

	public Integer getDrn_id() {
		return drn_id;
	}

	public void setDrn_id(Integer drn_id) {
		this.drn_id = drn_id;
	}

	public String getDrn_date() {
		return drn_date;
	}

	public void setDrn_date(String drn_date) {
		this.drn_date = drn_date;
	}

	public String getDrn_name() {
		return drn_name;
	}

	public void setDrn_name(String drn_name) {
		this.drn_name = drn_name;
	}

	public String getDrn_manager() {
		return drn_manager;
	}

	public void setDrn_manager(String drn_manager) {
		this.drn_manager = drn_manager;
	}

	public String getDrn_yuanyin() {
		return drn_yuanyin;
	}

	public void setDrn_yuanyin(String drn_yuanyin) {
		this.drn_yuanyin = drn_yuanyin;
	}

	@Override
	public String toString() {
		return "Drain [drn_id=" + drn_id + ", drn_date=" + drn_date + ", drn_name=" + drn_name + ", drn_manager="
				+ drn_manager + ", drn_yuanyin=" + drn_yuanyin + "]";
	}
	
	
}
