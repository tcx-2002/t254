package com.zking.crm.client.drain.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.zking.crm.client.drain.model.Drain;
import com.zking.crm.common.dao.BaseDao;
import com.zking.crm.util.PageBean;

public class DrainDaoImpl extends BaseDao implements IDrainDao{

	@Override
	public List<Drain> listDrain(Drain drain, PageBean pageBean) {
		String hql = "select d from Drain d where 1=1";
		Map<String,Object> params = new HashMap<>();
		if(drain != null) {
			if(drain.getDrn_name()!=null&&!"".equals(drain.getDrn_name())) {
				hql += " and d.drn_name like :drn_name ";
				params.put("drn_name", "%"+drain.getDrn_name()+"%");
			}
			if(drain.getDrn_manager()!=null&&!"".equals(drain.getDrn_manager())) {
				hql+="and d.drn_manager like :drn_manager ";
				params.put("drn_manager", "%"+drain.getDrn_manager()+"%");
			}
		}
		
		List<Drain> sal = this.query(hql, params, pageBean);
		return sal;
	}

	@Override
	public void addDrain(Drain drain) {
		// TODO Auto-generated method stub
		this.getHibernateTemplate().save(drain);
	}

}
