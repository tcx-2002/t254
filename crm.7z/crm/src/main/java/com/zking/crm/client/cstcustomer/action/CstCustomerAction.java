package com.zking.crm.client.cstcustomer.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ModelDriven;
import com.zking.crm.client.cstcustomer.model.CstCustomer;
import com.zking.crm.client.cstcustomer.service.ICstCustomerService;
import com.zking.crm.common.action.BaseAction;
import com.zking.crm.util.PageBean;

public class CstCustomerAction extends BaseAction implements ModelDriven<CstCustomer>{

	private CstCustomer customer = new CstCustomer();
	
	@Override
	public CstCustomer getModel() {
		// TODO Auto-generated method stub
		return customer;
	}
	
	private ICstCustomerService cstCustomerService;

	public ICstCustomerService getCstCustomerService() {
		return cstCustomerService;
	}

	public void setCstCustomerService(ICstCustomerService cstCustomerService) {
		this.cstCustomerService = cstCustomerService;
	}
	
	public void getCstCustomers() {
		PageBean pageBean = new PageBean();
		pageBean.setRequest(ServletActionContext.getRequest());
		
		List<CstCustomer> customers = cstCustomerService.getCstCustomersPage(customer, pageBean);
		
		Map<String, Object> data = new HashMap<String, Object>();
		data.put("total", pageBean.getTotal());
		data.put("totalPageNum", pageBean.getTotalPageNum());
		data.put("page", pageBean.getPage());
		data.put("rows", pageBean.getRows());
		data.put("data", customers);

		this.writeAsJson(data);
	}
	
	/**
	 * 
	 */
	public void addCstCustomer() {
		System.out.println("3"+this.customer);
		Map<String, Object> map = new HashMap<>();
		try {
			cstCustomerService.addCstCustomer(this.customer);
			map.put("success", true);
			map.put("msg", "操作成功");
		} catch (Exception e) {
			map.put("success", false);
			map.put("msg", "操作失败");
		}
		this.writeAsJson(map);
	}
	
	/**
	 * 修改书本信息
	 */
	public void updateCstCustomer() {
		Map<String, Object> map = new HashMap<>();
		try {
			cstCustomerService.updateCstCustomer(customer);
			map.put("success", true);
			map.put("msg", "操作成功");
		} catch (Exception e) {
			map.put("success", false);
			map.put("msg", "操作失败");
		}
		this.writeAsJson(map);
	}
	
	
	/**
	 * 删除书本信息
	 */
	public void delCstCustomer() {
		Map<String, Object> map = new HashMap<>();
		try {
			cstCustomerService.delCstCustomer(customer);
			map.put("success", true);
			map.put("msg", "操作成功");
		} catch (Exception e) {
			map.put("success", false);
			map.put("msg", "操作失败");
		}
		this.writeAsJson(map);
	}
	
	public void selCstCustomer() {
		CstCustomer customer = cstCustomerService.selCstCustomer(this.customer);
		Map<String, Object> data = new HashMap<String, Object>();
		data.put("data", customer);

		this.writeAsJson(data);
	}
	
	public void listCstCustomer() {
		Map<String, Object> map = new HashMap<>();
		List<CstCustomer> cst = cstCustomerService.listCstCustomer();
		map.put("cst", cst);
		this.writeAsJson(map);
	}
}
