package com.zking.crm.client.constitue.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.opensymphony.xwork2.ModelDriven;
import com.zking.crm.client.constitue.model.Constitue;
import com.zking.crm.client.constitue.service.IConstitueService;
import com.zking.crm.common.action.BaseAction;

public class ConstitueAction extends BaseAction implements ModelDriven<Constitue>{
private Constitue constitue = new Constitue();

@Override
public Constitue getModel() {
	// TODO Auto-generated method stub
	return constitue;
}
private IConstitueService constitueService;

public IConstitueService getConstitueService() {
	return constitueService;
}
public void setConstitueService(IConstitueService constitueService) {
	this.constitueService = constitueService;
}



public void listConstitue() {
	Map<String, Object> map = new HashMap<>();
	List<Constitue> list = constitueService.listConstitue(constitue);
	map.put("stitues", list);
	this.writeAsJson(map);
}

public void listType() {
	Map<String, Object> map = new HashMap<>();
	List<Constitue> list = constitueService.listType();
	map.put("types", list);
	this.writeAsJson(map);
}
}
