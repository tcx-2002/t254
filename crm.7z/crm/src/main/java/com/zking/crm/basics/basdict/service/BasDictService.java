package com.zking.crm.basics.basdict.service;

import java.util.List;

import com.zking.crm.basics.basdict.dao.IBasDictDao;
import com.zking.crm.basics.basdict.model.BasDict;
import com.zking.crm.util.PageBean;

public class BasDictService implements IBasDictService{
private IBasDictDao basDictDao;



public IBasDictDao getBasDictDao() {
	return basDictDao;
}

public void setBasDictDao(IBasDictDao basDictDao) {
	this.basDictDao = basDictDao;
}

@Override
public List<BasDict> listBasDict(BasDict basDict, PageBean pageBean) {
	// TODO Auto-generated method stub
	return basDictDao.listBasDict(basDict, pageBean);
}

@Override
public Integer addBasDict(BasDict basDict) {
	// TODO Auto-generated method stub
	return basDictDao.addBasDict(basDict);
}

@Override
public void updateBasDict(BasDict basDict) {
	// TODO Auto-generated method stub
	basDictDao.updateBasDict(basDict);
}

@Override
public void deleteBasDict(int dictID) {
	// TODO Auto-generated method stub
	basDictDao.deleteBasDict(dictID);
}

@Override
public void deleteBasDictByItem(String dictItem) {
	// TODO Auto-generated method stub
	basDictDao.deleteBasDictByItem(dictItem);
}

@Override
public List<BasDict> basDictByDictItem(String dictItem) {
	// TODO Auto-generated method stub
	return basDictDao.basDictByDictItem(dictItem);
}

@Override
public BasDict basDictById(int dictID) {
	// TODO Auto-generated method stub
	return basDictDao.basDictById(dictID);
}

@Override
public List<BasDict> selCustAddrs() {
	// TODO Auto-generated method stub
	return basDictDao.selCustAddrs("7");
}



@Override
public List<BasDict> selCustSatisfy() {
	// TODO Auto-generated method stub
	return basDictDao.selCustSatisfy("9");
}

@Override
public List<BasDict> selCustLevelLabel() {
	// TODO Auto-generated method stub
	return basDictDao.selCustLevelLabel("2");
}

@Override
public List<BasDict> selCustCredit() {
	// TODO Auto-generated method stub
	return basDictDao.selCustCredit("6");
}

@Override
public BasDict selCstCustomerLevel(Integer dictID) {
	// TODO Auto-generated method stub
	return basDictDao.selCstCustomerLevel(dictID);
}

}
