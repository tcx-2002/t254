package com.zking.crm.elsemarket.storage.service;

import java.util.List;

import com.zking.crm.elsemarket.storage.dao.IStorageDao;
import com.zking.crm.elsemarket.storage.model.Storage;
import com.zking.crm.util.PageBean;

public class StorageService implements IStorageService{
private IStorageDao storageDao;

public IStorageDao getStorageDao() {
	return storageDao;
}

public void setStorageDao(IStorageDao storageDao) {
	this.storageDao = storageDao;
}

@Override
public List<Storage> listStorage(Storage storage, PageBean pageBean) {
	// TODO Auto-generated method stub
	return storageDao.listStorage(storage, pageBean);
}


}
