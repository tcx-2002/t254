package com.zking.crm.client.drain.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ModelDriven;
import com.zking.crm.client.drain.model.Drain;
import com.zking.crm.client.drain.service.IDrainService;
import com.zking.crm.common.action.BaseAction;
import com.zking.crm.elsemarket.product.model.Product;
import com.zking.crm.util.PageBean;

public class DrainAction extends BaseAction implements ModelDriven<Drain>{
private Drain drain = new Drain();

@Override
public Drain getModel() {
	// TODO Auto-generated method stub
	return drain;
}
private IDrainService drainService;

public IDrainService getDrainService() {
	return drainService;
}
public void setDrainService(IDrainService drainService) {
	this.drainService = drainService;
}


public void listDrain() {
	PageBean pageBean = new PageBean();
	pageBean.setRequest(ServletActionContext.getRequest());
	List<Drain> list = drainService.listDrain(drain, pageBean);
	Map<String, Object> data = new HashMap<>();
	data.put("total", pageBean.getTotal());
	data.put("totalPageNum", pageBean.getTotalPageNum());
	data.put("page", pageBean.getPage());
	data.put("rows", pageBean.getRows());
	data.put("data", list);
	this.writeAsJson(data);
}

public void addDrain() {
	Map<String, Object> map = new HashMap<>();
	try {
		drainService.addDrain(drain);
		map.put("success", true);
		map.put("msg", "增加成功");
	} catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
		map.put("success", false);
		map.put("msg", "增加失败");
	}
	this.writeAsJson(map);
}
}
