package com.zking.crm.statistics.stituexydview.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.opensymphony.xwork2.ModelDriven;
import com.zking.crm.common.action.BaseAction;
import com.zking.crm.statistics.stituexydview.model.StitueXydView;
import com.zking.crm.statistics.stituexydview.service.IStitueXydViewService;

public class StitueXydViewAction extends BaseAction implements ModelDriven<StitueXydView>{
private StitueXydView stitueXydView = new StitueXydView();

@Override
public StitueXydView getModel() {
	// TODO Auto-generated method stub
	return stitueXydView;
}

private IStitueXydViewService stitueXydViewService;

public IStitueXydViewService getStitueXydViewService() {
	return stitueXydViewService;
}

public void setStitueXydViewService(IStitueXydViewService stitueXydViewService) {
	this.stitueXydViewService = stitueXydViewService;
}
public void listStitueXyd() {
	Map<String, Object> map = new HashMap<>();
	List<StitueXydView> stitues = stitueXydViewService.listStitue();
	map.put("stitues", stitues);
	this.writeAsJson(map);
}

}
