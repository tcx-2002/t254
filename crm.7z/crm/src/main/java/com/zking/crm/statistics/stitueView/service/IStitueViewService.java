package com.zking.crm.statistics.stitueView.service;

import java.util.List;

import com.zking.crm.statistics.stitueView.model.StitueView;

public interface IStitueViewService {
	/**
	 * 查询所有
	 * @return
	 */
List<StitueView> listStitueView();
}
