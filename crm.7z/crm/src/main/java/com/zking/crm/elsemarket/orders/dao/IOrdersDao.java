package com.zking.crm.elsemarket.orders.dao;

import java.util.List;

import com.zking.crm.elsemarket.orders.entity.Orders;
import com.zking.crm.util.PageBean;


public interface IOrdersDao {
	
	public List<Orders> selOrders(int odr_custno);
	
	public List<Orders> getOrdersPage(Orders orders,PageBean pageBean);
}
