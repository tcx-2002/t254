package com.zking.crm.client.cstlinkman.service;

import java.util.List;

import com.zking.crm.client.cstlinkman.dao.ILinkManDao;
import com.zking.crm.client.cstlinkman.model.CstLinkman;
import com.zking.crm.util.PageBean;


public class LinkManServiceImpl implements ILinkManService{
	
	private ILinkManDao linkManDao;
	

	public ILinkManDao getLinkManDao() {
		return linkManDao;
	}

	public void setLinkManDao(ILinkManDao linkManDao) {
		this.linkManDao = linkManDao;
	}

	@Override
	public List<CstLinkman> selCstLinkman(String lkmCustNo) {
		// TODO Auto-generated method stub
		return linkManDao.selCstLinkman(lkmCustNo);
	}

	@Override
	public List<CstLinkman> getCstLinkmanPage(CstLinkman linkMan, PageBean pageBean) {
		// TODO Auto-generated method stub
		return linkManDao.getCstLinkmanPage(linkMan, pageBean);
	}

	@Override
	public void addCstLinkman(CstLinkman linkMan) {
		// TODO Auto-generated method stub
		linkManDao.addCstLinkman(linkMan);
	}

	@Override
	public void updateCstLinkman(CstLinkman linkMan) {
		// TODO Auto-generated method stub
		linkManDao.updateCstLinkman(linkMan);
	}

	@Override
	public void delCstLinkman(CstLinkman linkMan) {
		// TODO Auto-generated method stub
		linkManDao.delCstLinkman(linkMan);
	}
	

}
