package com.zking.crm.marketing.salplan.model;

import java.util.Date;

import com.alibaba.fastjson.annotation.JSONField;
public class SalPlan {
	private long plaId;
	private long plaChcId;
	@JSONField(format = "yyyy-MM-dd HH:mm:ss")  //FastJson包使用注解
	private Date plaDate;
	private String plaTodo;
	private String plaResult;

	public void setPlaId(long plaId) {
		this.plaId = plaId;
	}

	public long getPlaId() {
		return plaId;
	}

	public void setPlaChcId(long plaChcId) {
		this.plaChcId = plaChcId;
	}

	public long getPlaChcId() {
		return plaChcId;
	}

	public void setPlaDate(Date plaDate) {
		this.plaDate = plaDate;
	}

	public Date getPlaDate() {
		return plaDate;
	}

	public void setPlaTodo(String plaTodo) {
		this.plaTodo = plaTodo;
	}

	public String getPlaTodo() {
		return plaTodo;
	}

	public void setPlaResult(String plaResult) {
		this.plaResult = plaResult;
	}

	public String getPlaResult() {
		return plaResult;
	}

	@Override
	public String toString() {
		return "SalPlan [plaId=" + plaId + ", plaChcId=" + plaChcId + ", plaDate=" + plaDate + ", plaTodo=" + plaTodo
				+ ", plaResult=" + plaResult + "]";
	}

}
