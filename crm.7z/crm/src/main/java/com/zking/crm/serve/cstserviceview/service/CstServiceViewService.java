package com.zking.crm.serve.cstserviceview.service;

import java.util.List;

import com.zking.crm.serve.cstserviceview.dao.ICstServiceViewDao;
import com.zking.crm.serve.cstserviceview.model.CstServiceView;

public class CstServiceViewService implements ICstServiceViewService{
private ICstServiceViewDao cstServiceViewDao;

public ICstServiceViewDao getCstServiceViewDao() {
	return cstServiceViewDao;
}

public void setCstServiceViewDao(ICstServiceViewDao cstServiceViewDao) {
	this.cstServiceViewDao = cstServiceViewDao;
}

@Override
public List<CstServiceView> listCstServiceView(CstServiceView cstServiceView) {
	// TODO Auto-generated method stub
	return cstServiceViewDao.listCstServiceView(cstServiceView);
}

@Override
public List<CstServiceView> listCdate() {
	// TODO Auto-generated method stub
	return cstServiceViewDao.listCdate();
}

@Override
public void addCount(CstServiceView cstServiceView) {
	// TODO Auto-generated method stub
	cstServiceViewDao.addCount(cstServiceView);
}

@Override
public List<CstServiceView> listServiceView(Integer cdate) {
	// TODO Auto-generated method stub
	return cstServiceViewDao.listServiceView(cdate);
}

@Override
public List<CstServiceView> listCdate(Integer cdate) {
	// TODO Auto-generated method stub
	return cstServiceViewDao.listCdate(cdate);
}

//@Override
//public List<List<CstServiceView>> listServiceView(String[] options) {
//	// TODO Auto-generated method stub
//	return cstServiceViewDao.listServiceView(options);
//}



}
