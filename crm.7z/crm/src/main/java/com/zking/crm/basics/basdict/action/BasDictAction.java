package com.zking.crm.basics.basdict.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ModelDriven;
import com.zking.crm.basics.basdict.model.BasDict;
import com.zking.crm.basics.basdict.service.IBasDictService;
import com.zking.crm.common.action.BaseAction;
import com.zking.crm.util.PageBean;

public class BasDictAction extends BaseAction implements ModelDriven<BasDict> {
	private BasDict basDict = new BasDict();

	@Override
	public BasDict getModel() {
		// TODO Auto-generated method stub
		return basDict;
	}

	private IBasDictService basDictService;

	public IBasDictService getBasDictService() {
		return basDictService;
	}

	public void setBasDictService(IBasDictService basDictService) {
		this.basDictService = basDictService;
	}

	public void listBasDict() {
		System.out.println(basDict);
		PageBean pageBean = new PageBean();
		pageBean.setRequest(ServletActionContext.getRequest());
		List<BasDict> list = basDictService.listBasDict(basDict, pageBean);
		Map<String, Object> data = new HashMap<>();
		data.put("total", pageBean.getTotal());
		data.put("totalPageNum", pageBean.getTotalPageNum());
		data.put("page", pageBean.getPage());
		data.put("rows", pageBean.getRows());
		data.put("data", list);
		this.writeAsJson(data);
	}

	public void addBasDict() {
		System.out.println(basDict);
		Map<String, Object> map = new HashMap<>();
		Integer n = basDictService.addBasDict(basDict);
		if (n > 0) {
			map.put("success", true);
			map.put("msg", "增加成功");
		} else {
			map.put("success", false);
			map.put("msg", "增加失败");
		}
		this.writeAsJson(map);
	}

	public void deleteBasDict() {
		Map<String, Object> map = new HashMap<>();
		try {
			basDictService.deleteBasDict(basDict.getDictID());
			map.put("success", true);
			map.put("msg", "删除成功");
		} catch (Exception e) {
			// TODO: handle exception
			map.put("success", false);
			map.put("msg", "删除失败");
		}
		this.writeAsJson(map);
	}

	public void updateBasDict() {
		System.out.println("测试-------------"+basDict);
		Map<String, Object> map = new HashMap<>();
		try {
			basDictService.updateBasDict(basDict);
			map.put("success", true);
			map.put("msg", "修改成功");
		} catch (Exception e) {
			// TODO: handle exception
			map.put("success", false);
			map.put("msg", "修改失败");
		}
		this.writeAsJson(map);
	}

	public void ByDictItem() {
		Map<String, Object> map = new HashMap<>();
		System.out.println(basDict);
		List<BasDict> list = basDictService.basDictByDictItem(basDict.getDictItem());
		map.put("basDicts", list);
		this.writeAsJson(map);
	}
	public void basDictById() {
		Map<String, Object> map = new HashMap<>();
		System.out.println(basDict);
		BasDict basDict = basDictService.basDictById(this.basDict.getDictID());
		map.put("basDict", basDict);
		this.writeAsJson(map);
	}
	
	public void selCustAddrs() {
		List<BasDict> datas = basDictService.selCustAddrs();
		this.writeAsJson(datas);
	}
	
	/**
	 *查询客户等级
	 */
	public void selCustLevelLabel() {
		List<BasDict> datas = basDictService.selCustLevelLabel();
		this.writeAsJson(datas);
	}
	
	/**
	 *查询客户信用度 
	 */
	public void selCustCredit() {
		List<BasDict> datas = basDictService.selCustCredit();
		this.writeAsJson(datas);
	}
	

	/**
	 *查询客户满意度 
	 */
	public void selCustSatisfy() {
		List<BasDict> datas = basDictService.selCustSatisfy();
		this.writeAsJson(datas);
	}

	
	/**
	 * 通过id查找LEVEL对象
	 */
	public void selCstCustomerLevel() {
		Map<String, Object> map = new HashMap<>();
		BasDict basDict = basDictService.selCstCustomerLevel(this.basDict.getDictID());
		map.put("basDict", basDict);
		this.writeAsJson(map);
	}



}
