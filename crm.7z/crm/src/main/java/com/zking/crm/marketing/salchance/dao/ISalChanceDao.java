package com.zking.crm.marketing.salchance.dao;

import java.util.List;

import com.zking.crm.marketing.salchance.model.SalChance;
import com.zking.crm.util.PageBean;

public interface ISalChanceDao {
/**
 * 获取所有营销机会信息
 * @return
 */
List<SalChance> SalChanceList(SalChance salchance,PageBean pagebean);

/**
 * 增加营销机会信息
 * @param salchance 要增加的营销机会信息
 * @return 是否增加成功
 */
Integer addSalChance(SalChance salchance);
/**
 * 修改营销机会的方法
 * @param salchance 要修改的信息
 * @return 是否修改成功
 */
void updateSalChance(SalChance salchance);
/**
 * 删除销售机会的方法
 * @param chcId 要删除的销售机会编号
 * @return 
 */
void deleteSalChance(long chcId);
/**
 * 通过id查询出销售机会
 * @param chcId 销售机会id
 * @return 销售机会
 */
SalChance salChanceById(long chcId);

}
