package com.zking.crm.client.cstlost.service;

import java.util.List;

import com.zking.crm.client.cstlost.dao.ILostDao;
import com.zking.crm.client.cstlost.model.CstLost;
import com.zking.crm.util.PageBean;

public class LostServiceImpl implements ILostService{
	private ILostDao lostDao;

	public ILostDao getLostDao() {
		return lostDao;
	}

	public void setLostDao(ILostDao lostDao) {
		this.lostDao = lostDao;
	}


	@Override
	public List<CstLost> getCstLostPage(CstLost cstLost, PageBean pageBean) {
		// TODO Auto-generated method stub
		return lostDao.getCstLostPage(cstLost, pageBean);
	}

	

	@Override
	public void updateLostStatus2(CstLost cstLost) {
		// TODO Auto-generated method stub
		lostDao.updateLostStatus2(cstLost);
	}

	@Override
	public void updateLostStatus1(CstLost cstLost) {
		// TODO Auto-generated method stub
		lostDao.updateLostStatus1(cstLost);
	}
	
	

}
