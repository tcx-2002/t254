package com.zking.crm.client.contribute.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ModelDriven;
import com.zking.crm.client.contribute.model.Contribute;
import com.zking.crm.client.contribute.service.IContributeService;
import com.zking.crm.common.action.BaseAction;
import com.zking.crm.elsemarket.product.model.Product;
import com.zking.crm.util.PageBean;

public class ContributeAction extends BaseAction implements ModelDriven<Contribute>{
private Contribute contribute = new Contribute();

@Override
public Contribute getModel() {
	// TODO Auto-generated method stub
	return contribute;
}

private IContributeService contributeService;

public IContributeService getContributeService() {
	return contributeService;
}

public void setContributeService(IContributeService contributeService) {
	this.contributeService = contributeService;
}


public void listContribute() {
	System.out.println(contribute);
	PageBean pageBean = new PageBean();
	pageBean.setRequest(ServletActionContext.getRequest());
	List<Contribute> list = contributeService.listContribute(contribute, pageBean);
	Map<String, Object> data = new HashMap<>();
	data.put("total", pageBean.getTotal());
	data.put("totalPageNum", pageBean.getTotalPageNum());
	data.put("page", pageBean.getPage());
	data.put("rows", pageBean.getRows());
	data.put("data", list);
	this.writeAsJson(data);
}

public void listCdate() {
	Map<String, Object> map = new HashMap<>();
	List<Contribute> cdates = contributeService.listCdate();
	map.put("cdates", cdates);
	this.writeAsJson(map);
}
}
