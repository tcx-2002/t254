package com.zking.crm.jurisdiction.module.dao;

import java.util.List;

import com.zking.crm.jurisdiction.module.model.Module;


public interface IModuleDao {
	
	public List<Module> getModules(int pid) ;

}
