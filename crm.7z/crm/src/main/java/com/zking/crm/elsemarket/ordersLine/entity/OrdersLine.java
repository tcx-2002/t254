package com.zking.crm.elsemarket.ordersLine.entity;


   /**
    * orders_line 实体类
    * Sat Nov 28 17:26:59 CST 2020 bkx
    */ 


public class OrdersLine{
	private int odd_id;
	private int odd_order_id;
	private int odd_prod_id;
	private int odd_count;
	private String odd_unit;
	private double odd_price;
	private String prod_name;
	public int getOdd_id() {
		return odd_id;
	}
	public void setOdd_id(int odd_id) {
		this.odd_id = odd_id;
	}
	public int getOdd_order_id() {
		return odd_order_id;
	}
	public void setOdd_order_id(int odd_order_id) {
		this.odd_order_id = odd_order_id;
	}
	public int getOdd_prod_id() {
		return odd_prod_id;
	}
	public void setOdd_prod_id(int odd_prod_id) {
		this.odd_prod_id = odd_prod_id;
	}
	public int getOdd_count() {
		return odd_count;
	}
	public void setOdd_count(int odd_count) {
		this.odd_count = odd_count;
	}
	public String getOdd_unit() {
		return odd_unit;
	}
	public void setOdd_unit(String odd_unit) {
		this.odd_unit = odd_unit;
	}
	public double getOdd_price() {
		return odd_price;
	}
	public void setOdd_price(double odd_price) {
		this.odd_price = odd_price;
	}
	public String getProd_name() {
		return prod_name;
	}
	public void setProd_name(String prod_name) {
		this.prod_name = prod_name;
	}
	@Override
	public String toString() {
		return "OrdersLine [odd_id=" + odd_id + ", odd_order_id=" + odd_order_id + ", odd_prod_id=" + odd_prod_id
				+ ", odd_count=" + odd_count + ", odd_unit=" + odd_unit + ", odd_price=" + odd_price + ", prod_name="
				+ prod_name + "]";
	}
	
	
	
}

