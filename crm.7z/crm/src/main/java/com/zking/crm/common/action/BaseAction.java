package com.zking.crm.common.action;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;

/**
 * BaseAction 所有action公共的方法
 * @author Administrator
 *
 */
public abstract class BaseAction {
	
	protected void writeAsJson(Object val) {
		PrintWriter pw = null;
        try {
            pw = ServletActionContext.getResponse().getWriter();
            String jsonStringDateFormat = JSON.toJSONStringWithDateFormat(val,"yyyy-MM-dd HH:mm:ss", SerializerFeature.WriteDateUseDateFormat);
            pw.println(jsonStringDateFormat);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
        	if(pw != null) {
        		pw.close();
        	}
		}
    }
	
	public Object getRequestBody(Class clazz) {
		
		BufferedReader br;
		HttpServletRequest request = ServletActionContext.getRequest();
		try {
			br = request.getReader();
			String str, aStr = "";
			while((str = br.readLine()) != null){
				aStr += str;
			}
			System.out.println(aStr);
			Object obj = JSONObject.parseObject(aStr, clazz);
			return obj;
		} catch (IOException e) {
			throw new RuntimeException("设置参数失败: " + e);
		}
	}
		
}
