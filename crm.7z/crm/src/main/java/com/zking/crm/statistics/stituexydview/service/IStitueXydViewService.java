package com.zking.crm.statistics.stituexydview.service;

import java.util.List;

import com.zking.crm.statistics.stituexydview.model.StitueXydView;

public interface IStitueXydViewService {
	List<StitueXydView> listStitue();
}
