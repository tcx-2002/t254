package com.zking.crm.marketing.salplan.dao;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.zking.crm.common.dao.BaseDao;
import com.zking.crm.marketing.salplan.model.SalPlan;
import com.zking.crm.util.PageBean;

public class SalPlanDao extends BaseDao implements ISalPlanDao{

	@Override
	public List<SalPlan> salPlanList(SalPlan salPlan,PageBean pageBean) {
		String hql = "select p from SalPlan p where 1=1";
		Map<String,Object> params = new HashMap<>();
		if(salPlan != null 
				&& salPlan.getPlaTodo()!=null 
				&& !"".equals(salPlan.getPlaTodo())) {
			hql += " and p.plaTodo like :plaTodo";
			params.put("plaTodo", "%"+salPlan.getPlaTodo()+"%");
		}
		
		List<SalPlan> sal = this.query(hql, params, pageBean);
		return sal;
	}

	@Override
	public Integer addSalPlan(SalPlan salPlan) {
		Serializable Serializable = this.getHibernateTemplate().save(salPlan);
		return Integer.parseInt(Serializable.toString());
	}

	@Override
	public void updateSalPlan(SalPlan salPlan) {
		SalPlan salplan = this.getHibernateTemplate().get(SalPlan.class, salPlan.getPlaId());
		if(salplan!=null) {
			salplan.setPlaDate(salPlan.getPlaDate());
			salplan.setPlaTodo(salPlan.getPlaTodo());
			salplan.setPlaResult(salPlan.getPlaResult());
		}
	}

	@Override
	public void deleteSalPlan(long plaId) {
		SalPlan salplan = this.getHibernateTemplate().get(SalPlan.class, plaId);
		if(salplan!=null) {
			this.getHibernateTemplate().delete(salplan);
		}
		
	}

	@Override
	public List<SalPlan> salPlanByChcId(long plaChcId) {
		String hql = "select p from SalPlan p where p.plaChcId=?";
		List<SalPlan> list =(List<SalPlan>)this.getHibernateTemplate().find(hql, plaChcId);
		return list;
	}

}
