package com.zking.crm.jurisdiction.module.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Module implements Serializable{
	
	private static final long serialVersionUID = -7798296749473641358L;

	private Integer id;
	
	private Integer pid;
	
	private String text;
	
	private String icon;
	
	private String url;
	
	private Integer sort;
	
	private Integer right;
	
	private List<Module> childrens = new ArrayList<>();
	
	

	public Integer getRight() {
		return right;
	}

	public void setRight(Integer right) {
		this.right = right;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getPid() {
		return pid;
	}

	public void setPid(Integer pid) {
		this.pid = pid;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getIcon() {
		return icon;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public Integer getSort() {
		return sort;
	}

	public void setSort(Integer sort) {
		this.sort = sort;
	}

	public List<Module> getChildrens() {
		return childrens;
	}

	public void setChildrens(List<Module> childrens) {
		this.childrens = childrens;
	}

	@Override
	public String toString() {
		return "Module [id=" + id + ", pid=" + pid + ", text=" + text + ", icon=" + icon + ", url=" + url + ", sort="
				+ sort + "]";
	}

}
