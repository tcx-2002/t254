package com.zking.crm.elsemarket.ordersLine.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.zking.crm.common.dao.BaseDao;
import com.zking.crm.elsemarket.ordersLine.entity.OrdersLine;
import com.zking.crm.util.PageBean;

public class OrdersLineDaoImpl extends BaseDao implements IOrdersLineDao{

	@Override
	public List<OrdersLine> selOrdersLine(int odd_order_id) {
		String hql ="from OrdersLine where odd_order_id = ?";
		List<OrdersLine> list = (List<OrdersLine>) this.getHibernateTemplate().find(hql, odd_order_id);
		if(list.size()>0) {
			return list;
		}
		return null;
	}

	@Override
	public List<OrdersLine> getOrdersLinePage(OrdersLine ordersLine, PageBean pageBean) {
		String hql = "select b from OrdersLine b where 1=1";
		Map<String,Object> params = new HashMap();
		if(ordersLine != null && ordersLine.getOdd_order_id()!= 0) {
			hql += " and b.odd_order_id = :odd_order_id";
			params.put("odd_order_id", ordersLine.getOdd_order_id());
		}
		
		List<OrdersLine> ordersLines = this.query(hql, params, pageBean);
		return ordersLines;
	}
	
	

}
