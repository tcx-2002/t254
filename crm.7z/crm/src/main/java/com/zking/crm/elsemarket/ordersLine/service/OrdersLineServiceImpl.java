package com.zking.crm.elsemarket.ordersLine.service;

import java.util.List;

import com.zking.crm.elsemarket.ordersLine.dao.IOrdersLineDao;
import com.zking.crm.elsemarket.ordersLine.entity.OrdersLine;
import com.zking.crm.util.PageBean;

public class OrdersLineServiceImpl implements IOrdersLineService{
	
	private IOrdersLineDao ordersLineDao;
	
	public IOrdersLineDao getOrdersLineDao() {
		return ordersLineDao;
	}

	public void setOrdersLineDao(IOrdersLineDao ordersLineDao) {
		this.ordersLineDao = ordersLineDao;
	}

	@Override
	public List<OrdersLine> selOrdersLine(int odd_order_id) {
		// TODO Auto-generated method stub
		return ordersLineDao.selOrdersLine(odd_order_id);
	}

	@Override
	public List<OrdersLine> getOrdersLinePage(OrdersLine ordersLine, PageBean pageBean) {
		// TODO Auto-generated method stub
		return ordersLineDao.getOrdersLinePage(ordersLine, pageBean);
	}
	
	

}
