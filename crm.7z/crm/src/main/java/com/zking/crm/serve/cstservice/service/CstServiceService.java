package com.zking.crm.serve.cstservice.service;

import java.util.List;

import com.zking.crm.serve.cstservice.dao.ICstServiceDao;
import com.zking.crm.serve.cstservice.model.CstService;
import com.zking.crm.serve.cstserviceview.model.CstServiceView;
import com.zking.crm.util.PageBean;

public class CstServiceService implements ICstServiceService{
private ICstServiceDao cstServiceDao;

public ICstServiceDao getCstServiceDao() {
	return cstServiceDao;
}

public void setCstServiceDao(ICstServiceDao cstServiceDao) {
	this.cstServiceDao = cstServiceDao;
}

@Override
public List<CstService> listCstService(CstService cstService, PageBean pagebean) {
	// TODO Auto-generated method stub
	return cstServiceDao.listCstService(cstService, pagebean);
}

@Override
public Integer addCstService(CstService cstService) {
	// TODO Auto-generated method stub
	return cstServiceDao.addCstService(cstService);
}

@Override
public void deleteCstService(long svrId) {
	// TODO Auto-generated method stub
	cstServiceDao.deleteCstService(svrId);
}

@Override
public void updateCtsService(CstService cstService) {
	// TODO Auto-generated method stub
	cstServiceDao.updateCtsService(cstService);
}



}
