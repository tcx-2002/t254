package com.zking.crm.statistics.stituemydview.service;

import java.util.List;

import com.zking.crm.statistics.stituemydview.model.StitueMydView;

public interface IStitueMydViewService {
	/**
	 * 查询所有
	 * @return
	 */
List<StitueMydView> listStitueView();
}
