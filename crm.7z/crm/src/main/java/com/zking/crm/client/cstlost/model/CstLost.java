package com.zking.crm.client.cstlost.model;


import java.util.Date;



public class CstLost{
	private long lstId;
	private String lstCustNo;
	private String lstCustName;
	private long lstCustManagerId;
	private String lstCustManagerName;
	private Date lstLastOrderDate;
	private Date lstLostDate;
	private String lstDelay;
	private String lstReason;
	private String lstStatus;
	public void setLstId(long lstId){
	this.lstId=lstId;
	}
	public long getLstId(){
		return lstId;
	}
	public void setLstCustNo(String lstCustNo){
	this.lstCustNo=lstCustNo;
	}
	public String getLstCustNo(){
		return lstCustNo;
	}
	public void setLstCustName(String lstCustName){
	this.lstCustName=lstCustName;
	}
	public String getLstCustName(){
		return lstCustName;
	}
	public void setLstCustManagerId(long lstCustManagerId){
	this.lstCustManagerId=lstCustManagerId;
	}
	public long getLstCustManagerId(){
		return lstCustManagerId;
	}
	public void setLstCustManagerName(String lstCustManagerName){
	this.lstCustManagerName=lstCustManagerName;
	}
	public String getLstCustManagerName(){
		return lstCustManagerName;
	}
	public void setLstLastOrderDate(Date lstLastOrderDate){
	this.lstLastOrderDate=lstLastOrderDate;
	}
	public Date getLstLastOrderDate(){
		return lstLastOrderDate;
	}
	public void setLstLostDate(Date lstLostDate){
	this.lstLostDate=lstLostDate;
	}
	public Date getLstLostDate(){
		return lstLostDate;
	}
	public void setLstDelay(String lstDelay){
	this.lstDelay=lstDelay;
	}
	public String getLstDelay(){
		return lstDelay;
	}
	public void setLstReason(String lstReason){
	this.lstReason=lstReason;
	}
	public String getLstReason(){
		return lstReason;
	}
	public void setLstStatus(String lstStatus){
	this.lstStatus=lstStatus;
	}
	public String getLstStatus(){
		return lstStatus;
	}
}

