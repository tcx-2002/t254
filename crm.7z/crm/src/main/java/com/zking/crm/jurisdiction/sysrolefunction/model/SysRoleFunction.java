package com.zking.crm.jurisdiction.sysrolefunction.model;




public class SysRoleFunction{
	private long rfId;
	private long roleId;
	private long functionId;
	public void setRfId(long rfId){
	this.rfId=rfId;
	}
	public long getRfId(){
		return rfId;
	}
	public void setRoleId(long roleId){
	this.roleId=roleId;
	}
	public long getRoleId(){
		return roleId;
	}
	public void setFunctionId(long functionId){
	this.functionId=functionId;
	}
	public long getFunctionId(){
		return functionId;
	}
}

