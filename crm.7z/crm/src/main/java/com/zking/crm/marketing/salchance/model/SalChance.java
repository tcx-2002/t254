package com.zking.crm.marketing.salchance.model;


import java.io.Serializable;
import java.util.Date;

import com.alibaba.fastjson.annotation.JSONField;

/**
 * 营销机会
 * @author 2019092601
 *
 */

public class SalChance {
	
	private long chcId;
	private String chcSource;
	private String chcCustName;
	private String chcTitle;
	private int chcRate;
	private String chcLinkman;
	private String chcTel;
	private String chcDesc;
	private long chcCreateId;
	private String chcCreateBy;
	@JSONField(format = "yyyy-MM-dd HH:mm:ss")  //FastJson包使用注解
	private Date chcCreateDate;
	private long chcDueId;
	private String chcDueTo;
	private Date chcDueDate;
	private String chcStatus;

	
	
	
	
	public long getChcId() {
		return chcId;
	}

	public void setChcId(long chcId) {
		this.chcId = chcId;
	}

	public String getChcSource() {
		return chcSource;
	}

	public void setChcSource(String chcSource) {
		this.chcSource = chcSource;
	}

	public String getChcCustName() {
		return chcCustName;
	}

	public void setChcCustName(String chcCustName) {
		this.chcCustName = chcCustName;
	}

	public String getChcTitle() {
		return chcTitle;
	}

	public void setChcTitle(String chcTitle) {
		this.chcTitle = chcTitle;
	}

	public int getChcRate() {
		return chcRate;
	}

	public void setChcRate(int chcRate) {
		this.chcRate = chcRate;
	}

	public String getChcLinkman() {
		return chcLinkman;
	}

	public void setChcLinkman(String chcLinkman) {
		this.chcLinkman = chcLinkman;
	}

	public String getChcTel() {
		return chcTel;
	}

	public void setChcTel(String chcTel) {
		this.chcTel = chcTel;
	}

	public String getChcDesc() {
		return chcDesc;
	}

	public void setChcDesc(String chcDesc) {
		this.chcDesc = chcDesc;
	}

	public long getChcCreateId() {
		return chcCreateId;
	}

	public void setChcCreateId(long chcCreateId) {
		this.chcCreateId = chcCreateId;
	}

	public String getChcCreateBy() {
		return chcCreateBy;
	}

	public void setChcCreateBy(String chcCreateBy) {
		this.chcCreateBy = chcCreateBy;
	}

	public Date getChcCreateDate() {
		return chcCreateDate;
	}

	public void setChcCreateDate(Date chcCreateDate) {
		this.chcCreateDate = chcCreateDate;
	}

	public long getChcDueId() {
		return chcDueId;
	}

	public void setChcDueId(long chcDueId) {
		this.chcDueId = chcDueId;
	}

	public String getChcDueTo() {
		return chcDueTo;
	}

	public void setChcDueTo(String chcDueTo) {
		this.chcDueTo = chcDueTo;
	}

	public Date getChcDueDate() {
		return chcDueDate;
	}

	public void setChcDueDate(Date chcDueDate) {
		this.chcDueDate = chcDueDate;
	}

	public String getChcStatus() {
		return chcStatus;
	}

	public void setChcStatus(String chcStatus) {
		this.chcStatus = chcStatus;
	}

	public SalChance() {
		// TODO Auto-generated constructor stub
	}
	
	public SalChance(String chcSource, String chcCustName, String chcTitle, int chcRate, String chcLinkman,
			String chcTel, String chcDesc, long chcCreateId, String chcCreateBy, Date chcCreateDate, long chcDueId,
			String chcDueTo, Date chcDueDate, String chcStatus) {
		super();
		this.chcSource = chcSource;
		this.chcCustName = chcCustName;
		this.chcTitle = chcTitle;
		this.chcRate = chcRate;
		this.chcLinkman = chcLinkman;
		this.chcTel = chcTel;
		this.chcDesc = chcDesc;
		this.chcCreateId = chcCreateId;
		this.chcCreateBy = chcCreateBy;
		this.chcCreateDate = chcCreateDate;
		this.chcDueId = chcDueId;
		this.chcDueTo = chcDueTo;
		this.chcDueDate = chcDueDate;
		this.chcStatus = chcStatus;
	}
	
	public SalChance(long chcId, String chcSource, String chcCustName, String chcTitle, int chcRate, String chcLinkman,
			String chcTel, String chcDesc, long chcCreateId, String chcCreateBy, Date chcCreateDate, long chcDueId,
			String chcDueTo, Date chcDueDate, String chcStatus) {
		super();
		this.chcId = chcId;
		this.chcSource = chcSource;
		this.chcCustName = chcCustName;
		this.chcTitle = chcTitle;
		this.chcRate = chcRate;
		this.chcLinkman = chcLinkman;
		this.chcTel = chcTel;
		this.chcDesc = chcDesc;
		this.chcCreateId = chcCreateId;
		this.chcCreateBy = chcCreateBy;
		this.chcCreateDate = chcCreateDate;
		this.chcDueId = chcDueId;
		this.chcDueTo = chcDueTo;
		this.chcDueDate = chcDueDate;
		this.chcStatus = chcStatus;
	}
	@Override
	public String toString() {
		return "SalChance [chcId=" + chcId + ", chcSource=" + chcSource + ", chcCustName=" + chcCustName + ", chcTitle="
				+ chcTitle + ", chcRate=" + chcRate + ", chcLinkman=" + chcLinkman + ", chcTel=" + chcTel + ", chcDesc="
				+ chcDesc + ", chcCreateId=" + chcCreateId + ", chcCreateBy=" + chcCreateBy + ", chcCreateDate="
				+ chcCreateDate + ", chcDueId=" + chcDueId + ", chcDueTo=" + chcDueTo + ", chcDueDate=" + chcDueDate
				+ ", chcStatus=" + chcStatus + "]";
	}
	
	
	
}

