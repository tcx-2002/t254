package com.zking.crm.client.cstlinkman.model;



public class CstLinkman{
	private long lkmId;
	private String lkmCustNo;
	private String lkmCustName;
	private String lkmName;
	private String lkmSex;
	private String lkmPostion;
	private String lkmTel;
	private String lkmMobile;
	private String lkmMemo;
	public void setLkmId(long lkmId){
	this.lkmId=lkmId;
	}
	public long getLkmId(){
		return lkmId;
	}
	public void setLkmCustNo(String lkmCustNo){
	this.lkmCustNo=lkmCustNo;
	}
	public String getLkmCustNo(){
		return lkmCustNo;
	}
	public void setLkmCustName(String lkmCustName){
	this.lkmCustName=lkmCustName;
	}
	public String getLkmCustName(){
		return lkmCustName;
	}
	public void setLkmName(String lkmName){
	this.lkmName=lkmName;
	}
	public String getLkmName(){
		return lkmName;
	}
	public void setLkmSex(String lkmSex){
	this.lkmSex=lkmSex;
	}
	public String getLkmSex(){
		return lkmSex;
	}
	public void setLkmPostion(String lkmPostion){
	this.lkmPostion=lkmPostion;
	}
	public String getLkmPostion(){
		return lkmPostion;
	}
	public void setLkmTel(String lkmTel){
	this.lkmTel=lkmTel;
	}
	public String getLkmTel(){
		return lkmTel;
	}
	public void setLkmMobile(String lkmMobile){
	this.lkmMobile=lkmMobile;
	}
	public String getLkmMobile(){
		return lkmMobile;
	}
	public void setLkmMemo(String lkmMemo){
	this.lkmMemo=lkmMemo;
	}
	public String getLkmMemo(){
		return lkmMemo;
	}
}

