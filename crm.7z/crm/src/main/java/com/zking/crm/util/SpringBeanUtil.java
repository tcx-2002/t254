package com.zking.crm.util;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

/**
 * 用于�?化Bean的获�?.
 * 
 * ApplicationContextAware接口�?
 * 实现了这个接口的bean，当spring容器初始化的时�?�，会自动的将ApplicationContext注入进来
 * 
 * @author Administrator
 */
public final class SpringBeanUtil implements ApplicationContextAware {
	
	private SpringBeanUtil() {
	}
	
	private static ApplicationContext cxt;

	@Override
	public void setApplicationContext(ApplicationContext appContext) throws BeansException {
		cxt = appContext;
	}
	
	
	/**
	 * 根据Bean的id来获取Bean对象
	 * @param id 配置文件中的bean的id属�??
	 * @return Object
	 */
	@SuppressWarnings("unchecked")
	public static <T> T getBean(String id) {
		return (T)cxt.getBean(id);
	}
	
} 