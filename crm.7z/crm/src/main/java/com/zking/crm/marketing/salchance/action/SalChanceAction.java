package com.zking.crm.marketing.salchance.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ModelDriven;
import com.zking.crm.common.action.BaseAction;
import com.zking.crm.marketing.salchance.model.SalChance;
import com.zking.crm.marketing.salchance.service.ISalChanceService;
import com.zking.crm.util.PageBean;

public class SalChanceAction extends BaseAction implements ModelDriven<SalChance> {
	private SalChance salChance = new SalChance();

	@Override
	public SalChance getModel() {
		return salChance;
	}
//依赖注入模块
	private ISalChanceService salChanceService;

	public ISalChanceService getSalChanceService() {
		return salChanceService;
	}

	public void setSalChanceService(ISalChanceService salChanceService) {
		this.salChanceService = salChanceService;
	}
//处理获取所有数据的Action
	public void salChanceList() {
		PageBean pageBean = new PageBean();
		pageBean.setRequest(ServletActionContext.getRequest());
		List<SalChance> list = salChanceService.SalChanceList(salChance, pageBean);
		Map<String, Object> data = new HashMap<>();
		data.put("total", pageBean.getTotal());
		data.put("totalPageNum", pageBean.getTotalPageNum());
		data.put("page", pageBean.getPage());
		data.put("rows", pageBean.getRows());
		data.put("data", list);
		this.writeAsJson(data);
	}
//处理删除的Action
	public void salChanceAdd() {
		Map<String, Object> map = new HashMap<>();
		Integer n = salChanceService.addSalChance(salChance);
		if (n > 0) {
			map.put("success", true);
			map.put("msg", "增加成功");
		} else {
			map.put("success", false);
			map.put("msg", "增加失败");
		}
		this.writeAsJson(map);
	}
//处理删除的Action
	public void salChanceDelete() {
		 
		Map<String, Object> map = new HashMap<>();
		System.out.println(salChance.getChcId());
		try {
			salChanceService.deleteSalChance(salChance.getChcId());
			map.put("success", true);
			map.put("msg", "删除成功");
		} catch (Exception e) {
			e.printStackTrace();
			map.put("success", false);
			map.put("msg", "删除失败");
		}
		this.writeAsJson(map);
	}
	//处理修改的Action
	public void salChanceUpdate() {
		Map<String, Object> map = new HashMap<>();
		try {
			salChanceService.updateSalChance(salChance);
			map.put("success", true);
			map.put("msg", "修改成功");
		} catch (Exception e) {
			e.printStackTrace();
			map.put("success", false);
			map.put("msg", "修改失败");
		}
		this.writeAsJson(map);
	}
	/**
	 * 11.27 问题ERROR org.hibernate.engine.jdbc.spi.SqlExceptionHelper - Data source rejected establishment of connection,  message from server: "Too many connections"
	 * 已解决
	 * 问题内容，同一时间数据库连接过多，清除缓存重启服务器解决
	 */
	public void salChanceById() {
		Map<String, Object> map = new HashMap<>();
		SalChance salChance = salChanceService.salChanceById(this.salChance.getChcId());
		map.put("salChance", salChance);
		this.writeAsJson(map);
	}

}
