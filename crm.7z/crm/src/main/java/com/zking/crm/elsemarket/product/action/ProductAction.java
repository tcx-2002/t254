package com.zking.crm.elsemarket.product.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ModelDriven;
import com.zking.crm.common.action.BaseAction;
import com.zking.crm.elsemarket.product.model.Product;
import com.zking.crm.elsemarket.product.service.IProductService;
import com.zking.crm.marketing.salchance.model.SalChance;
import com.zking.crm.util.PageBean;

public class ProductAction extends BaseAction implements ModelDriven<Product>{
private Product product = new Product();

@Override
public Product getModel() {
	// TODO Auto-generated method stub
	return product;
}

private IProductService productService;

public IProductService getProductService() {
	return productService;
}

public void setProductService(IProductService productService) {
	this.productService = productService;
}


public void listProduct() {
	PageBean pageBean = new PageBean();
	pageBean.setRequest(ServletActionContext.getRequest());
	List<Product> list = productService.listProduct(product, pageBean);
	Map<String, Object> data = new HashMap<>();
	data.put("total", pageBean.getTotal());
	data.put("totalPageNum", pageBean.getTotalPageNum());
	data.put("page", pageBean.getPage());
	data.put("rows", pageBean.getRows());
	data.put("data", list);
	this.writeAsJson(data);
}
public void productBy() {
	Map<String, Object> map = new HashMap<>();
	Product produc = productService.productByid(this.product.getProd_id());
	map.put("product", produc);
	this.writeAsJson(produc);
}

public void selProduct() {
	Map<String, Object> map = new HashMap<String, Object>();
	Product product = productService.selProduct(this.product);
	map.put("product", product);
	this.writeAsJson(map);
}


public void listProductName() {
	Map<String, Object> map = new HashMap<>();
	List<Product> list = productService.listProductName();
	map.put("data", list);
	this.writeAsJson(map);
}
}
