package com.zking.crm.jurisdiction.sysroleright.model;



public class SysRoleRight{
	private long rfId;
	private long rfRoleId;
	private String rfRightCode;
	public void setRfId(long rfId){
	this.rfId=rfId;
	}
	public long getRfId(){
		return rfId;
	}
	public void setRfRoleId(long rfRoleId){
	this.rfRoleId=rfRoleId;
	}
	public long getRfRoleId(){
		return rfRoleId;
	}
	public void setRfRightCode(String rfRightCode){
	this.rfRightCode=rfRightCode;
	}
	public String getRfRightCode(){
		return rfRightCode;
	}
}

