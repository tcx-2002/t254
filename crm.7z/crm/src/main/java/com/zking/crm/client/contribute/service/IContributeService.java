package com.zking.crm.client.contribute.service;

import java.util.List;

import com.zking.crm.client.contribute.model.Contribute;
import com.zking.crm.util.PageBean;

public interface IContributeService {
	/**
	 * 分页查询所有客户贡献信息
	 * @param contribute
	 * @param pageBean
	 * @return
	 */
List<Contribute> listContribute(Contribute contribute,PageBean pageBean);
/**
 * 获取所有日期
 */
List<Contribute> listCdate();
}
