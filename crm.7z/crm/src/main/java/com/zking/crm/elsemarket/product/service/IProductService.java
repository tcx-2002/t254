package com.zking.crm.elsemarket.product.service;

import java.util.List;

import com.zking.crm.elsemarket.product.model.Product;
import com.zking.crm.util.PageBean;

public interface IProductService {
	/**
	 * 分页查询所有产品
	 * @param product 
	 * @param pageBean
	 * @return
	 */
List<Product> listProduct(Product product,PageBean pageBean);
/**
 * 通过产品id查询产品信息
 * @param prod_id
 * @return
 */
Product productByid(int prod_id);

Product selProduct(Product product);
/**
 * 查询所有
 * @return
 */
List<Product> listProductName();
}
