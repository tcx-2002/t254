package com.zking.crm.marketing.salplan.service;

import java.util.List;

import com.zking.crm.marketing.salplan.model.SalPlan;
import com.zking.crm.util.PageBean;

public interface ISalPlanService {
	/**
	 * 查询所有的客户计划
	 * 
	 * @return
	 */
	List<SalPlan> salPlanList(SalPlan salPlan,PageBean pageBean);

	/**
	 * 增加客户计划
	 * 
	 * @param salPlan
	 *            客户计划信息
	 * @return 客户计划
	 */
	Integer addSalPlan(SalPlan salPlan);

	/**
	 * 修改客户计划
	 * 
	 * @param salPlan
	 *            客户计划信息
	 */
	void updateSalPlan(SalPlan salPlan);

	/**
	 * 删除客户计划
	 * 
	 * @param plaId
	 */
	void deleteSalPlan(long plaId);
	/**
	 * 通过销售机会id查询出客户计划
	 * @param plaChcId
	 * @return
	 */
	List<SalPlan> salPlanByChcId(long plaChcId);
}
