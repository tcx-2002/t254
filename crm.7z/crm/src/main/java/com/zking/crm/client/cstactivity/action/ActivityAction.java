package com.zking.crm.client.cstactivity.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ModelDriven;
import com.zking.crm.client.cstactivity.model.CstActivity;
import com.zking.crm.client.cstactivity.service.IActivityService;
import com.zking.crm.common.action.BaseAction;
import com.zking.crm.util.PageBean;

public class ActivityAction extends BaseAction implements ModelDriven<CstActivity>{

	private CstActivity activity = new CstActivity();
	
	@Override
	public CstActivity getModel() {
		// TODO Auto-generated method stub
		return activity;
	}
	
	private IActivityService activityService;

	public IActivityService getActivityService() {
		return activityService;
	}

	public void setActivityService(IActivityService activityService) {
		this.activityService = activityService;
	}
	
	public void selCstActivity() {
		PageBean pageBean = new PageBean();
		pageBean.setRequest(ServletActionContext.getRequest());
		System.out.println("3"+this.activity.getAtvCustNo());
		System.out.println(this.activity);
		List<CstActivity> activitys = activityService.selCstActivity(this.activity.getAtvCustNo());
		System.out.println(activitys);
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("total", pageBean.getTotal());
		map.put("totalPageNum", pageBean.getTotalPageNum());
		map.put("page", pageBean.getPage());
		map.put("rows", pageBean.getRows());
		map.put("data", activitys);
		this.writeAsJson(map);
	}

	/**
	 * 增加书本信息
	 */
	public void addCstActivity() {
		Map<String, Object> map = new HashMap<>();
		try {
			activityService.addCstActivity(this.activity);
			map.put("success", true);
			map.put("msg", "操作成功");
		} catch (Exception e) {
			map.put("success", false);
			map.put("msg", "操作失败");
		}
		this.writeAsJson(map);
	}
	
	/**
	 * 增加书本信息
	 */
	public void delCstActivity() {
		Map<String, Object> map = new HashMap<>();
		try {
			activityService.delCstActivity(this.activity);
			map.put("success", true);
			map.put("msg", "操作成功");
		} catch (Exception e) {
			map.put("success", false);
			map.put("msg", "操作失败");
		}
		this.writeAsJson(map);
	}
	
	
	/**
	 * 增加书本信息
	 */
	public void updateCstActivity() {
		Map<String, Object> map = new HashMap<>();
		try {
			activityService.updateCstActivity(this.activity);
			map.put("success", true);
			map.put("msg", "操作成功");
		} catch (Exception e) {
			map.put("success", false);
			map.put("msg", "操作失败");
		}
		this.writeAsJson(map);
	}

}
