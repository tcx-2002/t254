package com.zking.crm.serve.cstservice.model;


import java.util.Date;



public class CstService{
	private long svrId;
	private String svrType;
	private String svrTitle;
	private String svrCustNo;
	private String svrCustName;
	private String svrStatus;
	private String svrRequest;
	private Long svrCreateId;
	private String svrCreateBy;
	private Date svrCreateDate;
	private String svrDueId;
	private String svrDueTo;
	private Date svrDueDate;
	private String svrDeal;
	private Long svrDealId;
	private String svrDealBy;
	private Date svrDealDate;
	private String svrResult;
	private Integer svrSatisfy;
	public void setSvrId(long svrId){
	this.svrId=svrId;
	}
	public long getSvrId(){
		return svrId;
	}
	public void setSvrType(String svrType){
	this.svrType=svrType;
	}
	public String getSvrType(){
		return svrType;
	}
	public void setSvrTitle(String svrTitle){
	this.svrTitle=svrTitle;
	}
	public String getSvrTitle(){
		return svrTitle;
	}
	public void setSvrCustNo(String svrCustNo){
	this.svrCustNo=svrCustNo;
	}
	public String getSvrCustNo(){
		return svrCustNo;
	}
	public void setSvrCustName(String svrCustName){
	this.svrCustName=svrCustName;
	}
	public String getSvrCustName(){
		return svrCustName;
	}
	public void setSvrStatus(String svrStatus){
	this.svrStatus=svrStatus;
	}
	public String getSvrStatus(){
		return svrStatus;
	}
	public void setSvrRequest(String svrRequest){
	this.svrRequest=svrRequest;
	}
	public String getSvrRequest(){
		return svrRequest;
	}
	public void setSvrCreateId(Long svrCreateId){
	this.svrCreateId=svrCreateId;
	}
	public Long getSvrCreateId(){
		return svrCreateId;
	}
	public void setSvrCreateBy(String svrCreateBy){
	this.svrCreateBy=svrCreateBy;
	}
	public String getSvrCreateBy(){
		return svrCreateBy;
	}
	public void setSvrCreateDate(Date svrCreateDate){
	this.svrCreateDate=svrCreateDate;
	}
	public Date getSvrCreateDate(){
		return svrCreateDate;
	}
	public void setSvrDueId(String svrDueId){
	this.svrDueId=svrDueId;
	}
	public String getSvrDueId(){
		return svrDueId;
	}
	public void setSvrDueTo(String svrDueTo){
	this.svrDueTo=svrDueTo;
	}
	public String getSvrDueTo(){
		return svrDueTo;
	}
	public void setSvrDueDate(Date svrDueDate){
	this.svrDueDate=svrDueDate;
	}
	public Date getSvrDueDate(){
		return svrDueDate;
	}
	public void setSvrDeal(String svrDeal){
	this.svrDeal=svrDeal;
	}
	public String getSvrDeal(){
		return svrDeal;
	}
	public void setSvrDealId(Long svrDealId){
	this.svrDealId=svrDealId;
	}
	public Long getSvrDealId(){
		return svrDealId;
	}
	public void setSvrDealBy(String svrDealBy){
	this.svrDealBy=svrDealBy;
	}
	public String getSvrDealBy(){
		return svrDealBy;
	}
	public void setSvrDealDate(Date svrDealDate){
	this.svrDealDate=svrDealDate;
	}
	public Date getSvrDealDate(){
		return svrDealDate;
	}
	public void setSvrResult(String svrResult){
	this.svrResult=svrResult;
	}
	public String getSvrResult(){
		return svrResult;
	}
	public void setSvrSatisfy(Integer svrSatisfy){
	this.svrSatisfy=svrSatisfy;
	}
	public Integer getSvrSatisfy(){
		return svrSatisfy;
	}
	@Override
	public String toString() {
		return "CstService [svrId=" + svrId + ", svrType=" + svrType + ", svrTitle=" + svrTitle + ", svrCustNo="
				+ svrCustNo + ", svrCustName=" + svrCustName + ", svrStatus=" + svrStatus + ", svrRequest=" + svrRequest
				+ ", svrCreateId=" + svrCreateId + ", svrCreateBy=" + svrCreateBy + ", svrCreateDate=" + svrCreateDate
				+ ", svrDueId=" + svrDueId + ", svrDueTo=" + svrDueTo + ", svrDueDate=" + svrDueDate + ", svrDeal="
				+ svrDeal + ", svrDealId=" + svrDealId + ", svrDealBy=" + svrDealBy + ", svrDealDate=" + svrDealDate
				+ ", svrResult=" + svrResult + ", svrSatisfy=" + svrSatisfy + "]";
	}
	
	
}

