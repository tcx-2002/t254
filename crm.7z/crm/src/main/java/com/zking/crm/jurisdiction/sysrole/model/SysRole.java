package com.zking.crm.jurisdiction.sysrole.model;

public class SysRole {
	private long roleId;
	private String roleName;
	private String roleDesc;
	private int roleFlag;

	public void setRoleId(long roleId) {
		this.roleId = roleId;
	}

	public long getRoleId() {
		return roleId;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleDesc(String roleDesc) {
		this.roleDesc = roleDesc;
	}

	public String getRoleDesc() {
		return roleDesc;
	}

	public void setRoleFlag(int roleFlag) {
		this.roleFlag = roleFlag;
	}

	public int getRoleFlag() {
		return roleFlag;
	}
}
