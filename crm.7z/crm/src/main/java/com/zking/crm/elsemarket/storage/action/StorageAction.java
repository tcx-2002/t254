package com.zking.crm.elsemarket.storage.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ModelDriven;
import com.zking.crm.common.action.BaseAction;
import com.zking.crm.elsemarket.product.model.Product;
import com.zking.crm.elsemarket.storage.model.Storage;
import com.zking.crm.elsemarket.storage.service.IStorageService;
import com.zking.crm.util.PageBean;

public class StorageAction extends BaseAction implements ModelDriven<Storage>{
	private Storage storage = new Storage();

	@Override
	public Storage getModel() {
		// TODO Auto-generated method stub
		return storage;
	}
	private IStorageService storageService;

	public IStorageService getStorageService() {
		return storageService;
	}
	public void setStorageService(IStorageService storageService) {
		this.storageService = storageService;
	}
	
	public void listStorage() {
		PageBean pageBean = new PageBean();
		pageBean.setRequest(ServletActionContext.getRequest());
		List<Storage> list = storageService.listStorage(storage, pageBean);
		Map<String, Object> data = new HashMap<>();
		data.put("total", pageBean.getTotal());
		data.put("totalPageNum", pageBean.getTotalPageNum());
		data.put("page", pageBean.getPage());
		data.put("rows", pageBean.getRows());
		data.put("data", list);
		this.writeAsJson(data);
	}
	
}
