package com.zking.crm.statistics.stituemydview.model;

public class StitueMydView {
private Integer dictId;
private String dictValue;
private Integer dccount;
public Integer getDictId() {
	return dictId;
}
public void setDictId(Integer dictId) {
	this.dictId = dictId;
}
public String getDictValue() {
	return dictValue;
}
public void setDictValue(String dictValue) {
	this.dictValue = dictValue;
}
public Integer getDccount() {
	return dccount;
}
public void setDccount(Integer dccount) {
	this.dccount = dccount;
}
@Override
public String toString() {
	return "StitueView [dictId=" + dictId + ", dictValue=" + dictValue + ", dccount=" + dccount + "]";
}

}
