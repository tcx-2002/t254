package com.zking.crm.client.cstactivity.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.zking.crm.client.cstactivity.model.CstActivity;
import com.zking.crm.common.dao.BaseDao;
import com.zking.crm.util.PageBean;


public class ActivityDaoImpl  extends BaseDao implements IActivityDao{

	@Override
	public List<CstActivity> selCstActivity(String atvCustNo) {
		String hql ="from CstActivity c where c.atvCustNo = ?";
		List<CstActivity> list = (List<CstActivity>) this.getHibernateTemplate().find(hql, atvCustNo);
		
		return list;
	}

	@Override
	public List<CstActivity> getCstActivityPage(CstActivity activity, PageBean pageBean) {
		String hql = "select b from CstLinkman b where 1=1";
		Map<String,Object> params = new HashMap();
		
		if(activity != null && activity.getAtvCustName()!=null && !"".equals(activity.getAtvCustName())) {
			hql += " and b.atvCustName like :atvCustName";
			params.put("atvCustName", "%"+activity.getAtvCustName()+"%");
		}
		
		List<CstActivity> activitys = this.query(hql, params, pageBean);
		return activitys;
	}

	@Override
	public void addCstActivity(CstActivity activity) {
		// TODO Auto-generated method stub
		this.getHibernateTemplate().save(activity);
	}

	@Override
	public void updateCstActivity(CstActivity activity) {
		// TODO Auto-generated method stub
		CstActivity a = this.getHibernateTemplate().get(CstActivity.class, activity.getAtvId());
				if(a != null) {
					a.setAtvDate(activity.getAtvDate());
					a.setAtvPlace(activity.getAtvPlace());
					a.setAtvRemark(activity.getAtvRemark());
					a.setAtvTitle(activity.getAtvTitle());
					a.setAtvDesc(activity.getAtvDesc());
				}
	}

	@Override
	public void delCstActivity(CstActivity activity) {
		CstActivity a = this.getHibernateTemplate().get(CstActivity.class, activity.getAtvId());
		if(a != null) {
			this.getHibernateTemplate().delete(a);
		}
	}
	
	

}
