package com.zking.crm.client.constitue.service;

import java.util.List;

import com.zking.crm.client.constitue.dao.IConstitueDao;
import com.zking.crm.client.constitue.model.Constitue;

public class ConstitueServiceImpl implements IConstitueService{
private IConstitueDao constitueDao;

public IConstitueDao getConstitueDao() {
	return constitueDao;
}

public void setConstitueDao(IConstitueDao constitueDao) {
	this.constitueDao = constitueDao;
}

@Override
public List<Constitue> listConstitue(Constitue constitue) {
	// TODO Auto-generated method stub
	return constitueDao.listConstitue(constitue);
}

@Override
public List<Constitue> listType() {
	// TODO Auto-generated method stub
	return constitueDao.listType();
}

}
