package com.zking.crm.elsemarket.ordersLine.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ModelDriven;
import com.zking.crm.common.action.BaseAction;
import com.zking.crm.elsemarket.ordersLine.entity.OrdersLine;
import com.zking.crm.elsemarket.ordersLine.service.IOrdersLineService;
import com.zking.crm.util.PageBean;

public class OrdersLineAction extends BaseAction implements ModelDriven<OrdersLine>{

	private OrdersLine ordersLine = new OrdersLine();
	
	
	@Override
	public OrdersLine getModel() {
		// TODO Auto-generated method stub
		return ordersLine;
	}
	
	private IOrdersLineService ordersLineService;


	public IOrdersLineService getOrdersLineService() {
		return ordersLineService;
	}

	public void setOrdersLineService(IOrdersLineService ordersLineService) {
		this.ordersLineService = ordersLineService;
	}
	
	public void selOrdersLine() {
		PageBean pageBean = new PageBean();
		pageBean.setRequest(ServletActionContext.getRequest());
		System.out.println("--1"+this.ordersLine);
		List<OrdersLine> ordersLine = ordersLineService.getOrdersLinePage(this.ordersLine, pageBean);
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("total", pageBean.getTotal());
		map.put("totalPageNum", pageBean.getTotalPageNum());
		map.put("page", pageBean.getPage());
		map.put("rows", pageBean.getRows());
		map.put("data", ordersLine);
		System.out.println("--"+ordersLine);
		this.writeAsJson(map);
	}


}
