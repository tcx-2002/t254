package com.zking.crm.elsemarket.orders.service;

import java.util.List;

import com.zking.crm.elsemarket.orders.entity.Orders;
import com.zking.crm.util.PageBean;

public interface IOrdersService {
	public List<Orders> selOrders(int odr_custno);
	
	public List<Orders> getOrdersPage(Orders orders,PageBean pageBean);
}
