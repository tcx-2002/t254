package com.zking.crm.statistics.stituemydview.service;

import java.util.List;

import com.zking.crm.statistics.stitueView.dao.IStitueViewDao;
import com.zking.crm.statistics.stituemydview.dao.IStitueMydViewDao;
import com.zking.crm.statistics.stituemydview.model.StitueMydView;

public class StitueMydViewService implements IStitueMydViewService{
private IStitueMydViewDao stitueMydViewDao;

public IStitueMydViewDao getStitueMydViewDao() {
	return stitueMydViewDao;
}

public void setStitueMydViewDao(IStitueMydViewDao stitueMydViewDao) {
	this.stitueMydViewDao = stitueMydViewDao;
}

@Override
public List<StitueMydView> listStitueView() {
	// TODO Auto-generated method stub
	return stitueMydViewDao.listStitueView();
}

}
