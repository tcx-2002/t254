package com.zking.crm.client.cstactivity.service;

import java.util.List;

import com.zking.crm.client.cstactivity.dao.IActivityDao;
import com.zking.crm.client.cstactivity.model.CstActivity;
import com.zking.crm.util.PageBean;


public class ActivityServiceImpl implements IActivityService{
	private IActivityDao activityDao;
	
	public IActivityDao getActivityDao() {
		return activityDao;
	}

	public void setActivityDao(IActivityDao activityDao) {
		this.activityDao = activityDao;
	}

	@Override
	public List<CstActivity> selCstActivity(String atvCustNo) {
		// TODO Auto-generated method stub
		return activityDao.selCstActivity(atvCustNo);
	}

	@Override
	public List<CstActivity> getCstActivityPage(CstActivity activity, PageBean pageBean) {
		// TODO Auto-generated method stub
		return activityDao.getCstActivityPage(activity, pageBean);
	}

	@Override
	public void addCstActivity(CstActivity activity) {
		// TODO Auto-generated method stub
		activityDao.addCstActivity(activity);
	}

	@Override
	public void updateCstActivity(CstActivity activity) {
		// TODO Auto-generated method stub
		activityDao.updateCstActivity(activity);
	}

	@Override
	public void delCstActivity(CstActivity activity) {
		// TODO Auto-generated method stub
		activityDao.delCstActivity(activity);
	}
	

}
