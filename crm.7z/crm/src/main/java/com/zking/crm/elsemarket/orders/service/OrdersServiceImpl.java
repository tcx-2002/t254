package com.zking.crm.elsemarket.orders.service;

import java.util.List;

import com.zking.crm.elsemarket.orders.dao.IOrdersDao;
import com.zking.crm.elsemarket.orders.entity.Orders;
import com.zking.crm.util.PageBean;

public class OrdersServiceImpl implements IOrdersService{
	
	private IOrdersDao ordersDao;
	
	public IOrdersDao getOrdersDao() {
		return ordersDao;
	}

	public void setOrdersDao(IOrdersDao ordersDao) {
		this.ordersDao = ordersDao;
	}

	@Override
	public List<Orders> selOrders(int odr_custno) {
		// TODO Auto-generated method stub
		return ordersDao.selOrders(odr_custno);
	}

	@Override
	public List<Orders> getOrdersPage(Orders orders, PageBean pageBean) {
		// TODO Auto-generated method stub
		return ordersDao.getOrdersPage(orders, pageBean);
	}
	

}
