package com.zking.crm.client.cstcustomer.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.orm.hibernate5.HibernateCallback;

import com.zking.crm.client.cstcustomer.model.CstCustomer;
import com.zking.crm.common.dao.BaseDao;
import com.zking.crm.util.PageBean;


public class CstCustomerDaoImpl extends BaseDao implements ICstCustomerDao{

	@Override
	public List<CstCustomer> getCstCustomers(CstCustomer customer) {
		String hql = "select b from CstCustomer b where 1=1";
		if(customer != null && customer.getCustName() != null && !"".equals(customer.getCustName())) {
			hql +=" and b.custName like :custName";
		}
		final String _hql = hql;
		
		List<CstCustomer> lst = this.getHibernateTemplate().execute(new HibernateCallback<List<CstCustomer>>() {

			@Override
			public List<CstCustomer> doInHibernate(Session session) throws HibernateException {
				Query<CstCustomer> query = session.createQuery(_hql);
				if(customer != null && customer.getCustName()  != null && !"".equals(customer.getCustName() )) {
					query.setParameter("custName", "%"+customer.getCustName()+"%");
				}
				return query.list();
			}
		
		});
		
		return lst;
	}

	@Override
	public List<CstCustomer> getCstCustomersPage(CstCustomer customer, PageBean pageBean) {
		String hql = "select b from CstCustomer b where 1=1";
		Map<String,Object> params = new HashMap();
		
		if(customer != null && customer.getCustName()!=null && !"".equals(customer.getCustName())) {
			hql += " and b.custName like :custName";
			params.put("custName", "%"+customer.getCustName()+"%");
		}
		
		List<CstCustomer> customers = this.query(hql, params, pageBean);
		return customers;
	}

	@Override
	public void addCstCustomer(CstCustomer customer) {
		// TODO Auto-generated method stub
		this.getHibernateTemplate().save(customer);
	}

	@Override
	public void updateCstCustomer(CstCustomer customer) {
		// TODO Auto-generated method stub
		CstCustomer b = this.getHibernateTemplate().get(CstCustomer.class, customer.getCustNo());
		if(b != null) {
			b.setCustName(customer.getCustName());
			b.setCustRegion(customer.getCustRegion());
			b.setCustManagerId(customer.getCustManagerId());
			b.setCustManagerName(customer.getCustManagerName());
			b.setCustLevel(customer.getCustLevel());
			b.setCustLevelLabel(customer.getCustLevelLabel());
			b.setCustSatisfy(customer.getCustSatisfy());
			b.setCustCredit(customer.getCustCredit());
			b.setCustAddr(customer.getCustAddr());
			b.setCustZip(customer.getCustZip());
			b.setCustFax(customer.getCustFax());
			b.setCustWebsite(customer.getCustWebsite());
			b.setCustLicenceNo(customer.getCustLicenceNo());
			b.setCustChieftain(customer.getCustChieftain());
			b.setCustBankroll(customer.getCustBankroll());
			b.setCustTurnover(customer.getCustTurnover());
			b.setCustBank(customer.getCustBank());
			b.setCustBankAccount(customer.getCustBankAccount());
			b.setCustLocalTaxNo(customer.getCustLocalTaxNo());
			b.setCustNationalTaxNo(customer.getCustNationalTaxNo());
		}
	}

	@Override
	public void delCstCustomer(CstCustomer customer) {
		// TODO Auto-generated method stub
		CstCustomer b = this.getHibernateTemplate().get(CstCustomer.class, customer.getCustNo());
		if(b != null) {
			this.getHibernateTemplate().delete(b);
		}
	}

	@Override
	public CstCustomer selCstCustomer(CstCustomer customer) {
		CstCustomer b = this.getHibernateTemplate().get(CstCustomer.class, customer.getCustNo());
		return b;
	}

	@Override
	public List<CstCustomer> listCstCustomer() {
		// TODO Auto-generated method stub
		String hql = "select c from CstCustomer c";
		List<CstCustomer> list = (List<CstCustomer>)this.getHibernateTemplate().find(hql);
		return list;
	}

	
}
