package com.zking.crm.elsemarket.orders.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.zking.crm.common.dao.BaseDao;
import com.zking.crm.elsemarket.orders.entity.Orders;
import com.zking.crm.util.PageBean;


public class OdersDaoImpl extends BaseDao implements IOrdersDao{

	@Override
	public List<Orders> selOrders(int odr_custno) {
		String hql ="from Orders where odr_custno = ?";
		List<Orders> list = (List<Orders>) this.getHibernateTemplate().find(hql, odr_custno);
		if(list.size()>0) {
			return list;
		}
		return null;
	}

	@Override
	public List<Orders> getOrdersPage(Orders orders, PageBean pageBean) {
		String hql = "select b from Orders b where 1=1";
		Map<String,Object> params = new HashMap();
		if(orders != null && orders.getOdr_custno()!= 0) {
			hql += " and b.odr_custno = :odr_custno";
			params.put("odr_custno", orders.getOdr_custno());
		}
		if(orders != null && orders.getOdr_custname()!= null) {
			hql += " and b.odr_custname like :odr_custname";
			params.put("odr_custname","%"+orders.getOdr_custname()+"%");
		}
		
		List<Orders> order = this.query(hql, params, pageBean);
		return order;
	}
	
	
	

}
