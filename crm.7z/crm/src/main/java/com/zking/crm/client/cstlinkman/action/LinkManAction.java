package com.zking.crm.client.cstlinkman.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ModelDriven;
import com.zking.crm.client.cstlinkman.model.CstLinkman;
import com.zking.crm.client.cstlinkman.service.ILinkManService;
import com.zking.crm.common.action.BaseAction;
import com.zking.crm.util.PageBean;

public class LinkManAction extends BaseAction implements ModelDriven<CstLinkman>{

	CstLinkman linkMan = new CstLinkman();
	
	@Override
	public CstLinkman getModel() {
		// TODO Auto-generated method stub
		return linkMan;
	}
	
	private ILinkManService linkManService;

	public ILinkManService getLinkManService() {
		return linkManService;
	}

	public void setLinkManService(ILinkManService linkManService) {
		this.linkManService = linkManService;
	}
	
	public void selCstLinkman() {
		PageBean pageBean = new PageBean();
		pageBean.setRequest(ServletActionContext.getRequest());
		List<CstLinkman> linkMans = linkManService.getCstLinkmanPage(this.linkMan, pageBean);
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("total", pageBean.getTotal());
		map.put("totalPageNum", pageBean.getTotalPageNum());
		map.put("page", pageBean.getPage());
		map.put("rows", pageBean.getRows());
		map.put("data", linkMans);
		System.out.println("--"+linkMans);
		this.writeAsJson(map);
	}

	/**
	 * 增加书本信息
	 */
	public void addCstLinkman() {
		System.out.println("3"+this.linkMan);
		Map<String, Object> map = new HashMap<>();
		try {
			linkManService.addCstLinkman(this.linkMan);
			map.put("success", true);
			map.put("msg", "操作成功");
		} catch (Exception e) {
			map.put("success", false);
			map.put("msg", "操作失败");
		}
		this.writeAsJson(map);
	}
	
	/**
	 * 增加书本信息
	 */
	public void delCstLinkman() {
		Map<String, Object> map = new HashMap<>();
		try {
			System.out.println("22"+this.linkMan.getLkmId());
			linkManService.delCstLinkman(this.linkMan);
			map.put("success", true);
			map.put("msg", "操作成功");
		} catch (Exception e) {
			map.put("success", false);
			map.put("msg", "操作失败");
		}
		this.writeAsJson(map);
	}
	
	
	/**
	 * 增加书本信息
	 */
	public void updateCstLinkman() {
		System.out.println("3"+this.linkMan);
		Map<String, Object> map = new HashMap<>();
		try {
			linkManService.updateCstLinkman(this.linkMan);
			map.put("success", true);
			map.put("msg", "操作成功");
		} catch (Exception e) {
			map.put("success", false);
			map.put("msg", "操作失败");
		}
		this.writeAsJson(map);
	}
	
	
}
