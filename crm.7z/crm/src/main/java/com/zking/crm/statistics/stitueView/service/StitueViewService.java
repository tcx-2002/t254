package com.zking.crm.statistics.stitueView.service;

import java.util.List;

import com.zking.crm.statistics.stitueView.dao.IStitueViewDao;
import com.zking.crm.statistics.stitueView.model.StitueView;

public class StitueViewService implements IStitueViewService{
private IStitueViewDao stitueViewDao;

public IStitueViewDao getStitueViewDao() {
	return stitueViewDao;
}

public void setStitueViewDao(IStitueViewDao stitueViewDao) {
	this.stitueViewDao = stitueViewDao;
}

@Override
public List<StitueView> listStitueView() {
	// TODO Auto-generated method stub
	return stitueViewDao.listStitueView();
}

}
