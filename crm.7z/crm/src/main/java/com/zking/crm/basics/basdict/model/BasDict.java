package com.zking.crm.basics.basdict.model;

public class BasDict{
	private int dictID;
	private String dictTypr;
	private String type;
	private String dictItem;
	private String dictValue;
	private int dictIsEditable;
	public void setDictID(int dictID){
	this.dictID=dictID;
	}
	public int getDictID(){
		return dictID;
	}
	public void setDictTypr(String dictTypr){
	this.dictTypr=dictTypr;
	}
	public String getDictTypr(){
		return dictTypr;
	}
	public void setType(String type){
	this.type=type;
	}
	public String getType(){
		return type;
	}
	public void setDictItem(String dictItem){
	this.dictItem=dictItem;
	}
	public String getDictItem(){
		return dictItem;
	}
	public void setDictValue(String dictValue){
	this.dictValue=dictValue;
	}
	public String getDictValue(){
		return dictValue;
	}
	public void setDictIsEditable(int dictIsEditable){
	this.dictIsEditable=dictIsEditable;
	}
	public int getDictIsEditable(){
		return dictIsEditable;
	}
	@Override
	public String toString() {
		return "BasDict [dictID=" + dictID + ", dictTypr=" + dictTypr + ", type=" + type + ", dictItem=" + dictItem
				+ ", dictValue=" + dictValue + ", dictIsEditable=" + dictIsEditable + "]";
	}
	
	
}

