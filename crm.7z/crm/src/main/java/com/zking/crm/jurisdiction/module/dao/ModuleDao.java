package com.zking.crm.jurisdiction.module.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.orm.hibernate5.HibernateCallback;

import com.zking.crm.common.dao.BaseDao;
import com.zking.crm.jurisdiction.module.model.Module;


public class ModuleDao extends BaseDao implements IModuleDao {

	@Override
	@SuppressWarnings({"unchecked","rawtypes"})
	public List<Module> getModules(int pid) {
		
		String hql = "from Module where pid = :pid";
		List<Module> lst = this.getHibernateTemplate().execute(new HibernateCallback<List<Module>>() {
			@Override
			public List<Module> doInHibernate(Session session) throws HibernateException {
				Query query = session.createQuery(hql);
				query.setParameter("pid", pid);
				return (List<Module>)query.list();
			}
		});
		
		if(lst != null && lst.size() >= 0) {
			for(Module m:  lst) {
				if(m.getUrl() == null || "".equals(m.getUrl())) {
					List<Module> cls = this.getModules(m.getId());
					m.setChildrens(cls);
				}
			}
		}
		
		return lst;
	}

}
