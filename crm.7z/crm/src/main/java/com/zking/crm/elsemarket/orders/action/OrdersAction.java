package com.zking.crm.elsemarket.orders.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ModelDriven;
import com.zking.crm.common.action.BaseAction;
import com.zking.crm.elsemarket.orders.entity.Orders;
import com.zking.crm.elsemarket.orders.service.IOrdersService;
import com.zking.crm.util.PageBean;

public class OrdersAction extends BaseAction implements ModelDriven<Orders>{

	private Orders order = new Orders();
	
	@Override
	public Orders getModel() {
		// TODO Auto-generated method stub
		return order;
	}

	private IOrdersService ordersService;

	public IOrdersService getOrdersService() {
		return ordersService;
	}

	public void setOrdersService(IOrdersService ordersService) {
		this.ordersService = ordersService;
	}
	
	public void selOrders() {
		PageBean pageBean = new PageBean();
		pageBean.setRequest(ServletActionContext.getRequest());
		System.out.println("--1"+this.order);
		List<Orders> orders = ordersService.getOrdersPage(this.order, pageBean);
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("total", pageBean.getTotal());
		map.put("totalPageNum", pageBean.getTotalPageNum());
		map.put("page", pageBean.getPage());
		map.put("rows", pageBean.getRows());
		map.put("data", orders);
		System.out.println("--"+orders);
		this.writeAsJson(map);
	}

	
}
