package com.zking.crm.client.cstcustomer.dao;

import java.util.List;

import com.zking.crm.client.cstcustomer.model.CstCustomer;
import com.zking.crm.util.PageBean;


public interface ICstCustomerDao {
	public List<CstCustomer> getCstCustomers(CstCustomer customer);
	
	public List<CstCustomer> getCstCustomersPage(CstCustomer customer,PageBean pageBean);
	
	public void addCstCustomer(CstCustomer customer);
	
	public void updateCstCustomer(CstCustomer customer);
	
	public void delCstCustomer(CstCustomer customer);
	
	public CstCustomer selCstCustomer(CstCustomer customer);
	
	List<CstCustomer> listCstCustomer();
}
