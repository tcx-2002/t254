package com.zking.crm.statistics.stitueView.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.opensymphony.xwork2.ModelDriven;
import com.zking.crm.common.action.BaseAction;
import com.zking.crm.statistics.stitueView.model.StitueView;
import com.zking.crm.statistics.stitueView.service.IStitueViewService;

public class StitueViewAction extends BaseAction implements ModelDriven<StitueView>{
private StitueView stitueView = new StitueView();

@Override
public StitueView getModel() {
	// TODO Auto-generated method stub
	return stitueView;
}

private IStitueViewService stitueViewService;

public IStitueViewService getStitueViewService() {
	return stitueViewService;
}

public void setStitueViewService(IStitueViewService stitueViewService) {
	this.stitueViewService = stitueViewService;
}

public void listStitueView() {
	Map<String, Object> map = new HashMap<>();
	List<StitueView> stitues = stitueViewService.listStitueView();
	map.put("stitues", stitues);
	this.writeAsJson(map);
}
}
