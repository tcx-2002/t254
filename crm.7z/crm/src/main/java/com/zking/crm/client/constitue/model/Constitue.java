package com.zking.crm.client.constitue.model;

public class Constitue {
	private Integer cte_id;
	
	private String cte_type;
	
	private String cte_level;
	
	private Integer cte_match;

	public Integer getCte_id() {
		return cte_id;
	}

	public void setCte_id(Integer cte_id) {
		this.cte_id = cte_id;
	}

	public String getCte_type() {
		return cte_type;
	}

	public void setCte_type(String cte_type) {
		this.cte_type = cte_type;
	}

	public String getCte_level() {
		return cte_level;
	}

	public void setCte_level(String cte_level) {
		this.cte_level = cte_level;
	}

	public Integer getCte_match() {
		return cte_match;
	}

	public void setCte_match(Integer cte_match) {
		this.cte_match = cte_match;
	}

	@Override
	public String toString() {
		return "Constitue [cte_id=" + cte_id + ", cte_type=" + cte_type + ", cte_level=" + cte_level + ", cte_match="
				+ cte_match + "]";
	}
	
	
}
