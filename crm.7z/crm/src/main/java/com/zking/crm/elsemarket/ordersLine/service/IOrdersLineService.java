package com.zking.crm.elsemarket.ordersLine.service;

import java.util.List;

import com.zking.crm.elsemarket.ordersLine.entity.OrdersLine;
import com.zking.crm.util.PageBean;

public interface IOrdersLineService {
	
	public List<OrdersLine> selOrdersLine(int odd_order_id);
	
	public List<OrdersLine> getOrdersLinePage(OrdersLine ordersLine,PageBean pageBean);

}
