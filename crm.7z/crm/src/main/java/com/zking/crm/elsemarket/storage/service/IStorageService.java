package com.zking.crm.elsemarket.storage.service;

import java.util.List;

import com.zking.crm.elsemarket.storage.model.Storage;
import com.zking.crm.util.PageBean;

public interface IStorageService {
	/**
	 * 查询所有库存
	 * @param storage
	 * @param pageBean
	 * @return
	 */
List<Storage> listStorage(Storage storage,PageBean pageBean);
}
