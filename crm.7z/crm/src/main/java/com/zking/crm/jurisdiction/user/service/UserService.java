package com.zking.crm.jurisdiction.user.service;

import java.util.List;

import com.zking.crm.jurisdiction.user.dao.IUserDao;
import com.zking.crm.jurisdiction.user.model.User;

public class UserService implements IUserService{

	private IUserDao userDao;
	
	public IUserDao getUserDao() {
		return userDao;
	}

	public void setUserDao(IUserDao userDao) {
		this.userDao = userDao;
	}

	@Override
	public User login(User user) {
		// TODO Auto-generated method stub
		return userDao.login(user);
	}

	@Override
	public Integer addUser(User user) {
		// TODO Auto-generated method stub
		return userDao.addUser(user);
	}

	@Override
	public List<User> userAM() {
		// TODO Auto-generated method stub
		return userDao.userAM();
	}

	@Override
	public User userById(Integer usrId) {
		// TODO Auto-generated method stub
		return userDao.userById(usrId);
	}
	
	@Override
	public List<User> selCustManagerName() {
		// TODO Auto-generated method stub
		return userDao.selCustManagerName(3);
	}


}
