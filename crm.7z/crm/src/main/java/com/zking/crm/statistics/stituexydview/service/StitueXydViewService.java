package com.zking.crm.statistics.stituexydview.service;

import java.util.List;

import com.zking.crm.statistics.stituemydview.model.StitueMydView;
import com.zking.crm.statistics.stituemydview.service.IStitueMydViewService;
import com.zking.crm.statistics.stituexydview.dao.IStitueXydViewDao;
import com.zking.crm.statistics.stituexydview.model.StitueXydView;

public class StitueXydViewService implements IStitueXydViewService{
private IStitueXydViewDao stitueXydViewDao;

public IStitueXydViewDao getStitueXydViewDao() {
	return stitueXydViewDao;
}

public void setStitueXydViewDao(IStitueXydViewDao stitueXydViewDao) {
	this.stitueXydViewDao = stitueXydViewDao;
}

@Override
public List<StitueXydView> listStitue() {
	// TODO Auto-generated method stub
	return stitueXydViewDao.listStitue();
}


}
