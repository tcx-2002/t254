package com.zking.crm.client.contribute.service;

import java.util.List;

import com.zking.crm.client.contribute.dao.IContributeDao;
import com.zking.crm.client.contribute.model.Contribute;
import com.zking.crm.util.PageBean;

public class ContributeServiceImpl implements IContributeService{
private IContributeDao contributeDao;

public IContributeDao getContributeDao() {
	return contributeDao;
}

public void setContributeDao(IContributeDao contributeDao) {
	this.contributeDao = contributeDao;
}

@Override
public List<Contribute> listContribute(Contribute contribute, PageBean pageBean) {
	// TODO Auto-generated method stub
	return contributeDao.listContribute(contribute, pageBean);
}

@Override
public List<Contribute> listCdate() {
	// TODO Auto-generated method stub
	return contributeDao.listCdate();
}

}
