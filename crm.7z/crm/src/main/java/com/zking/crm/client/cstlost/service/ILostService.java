package com.zking.crm.client.cstlost.service;

import java.util.List;

import com.zking.crm.client.cstlost.model.CstLost;
import com.zking.crm.util.PageBean;


public interface ILostService {
	
	
	public List<CstLost> getCstLostPage(CstLost cstLost,PageBean pageBean);

	public void updateLostStatus1(CstLost cstLost);
	
	public void updateLostStatus2(CstLost cstLost);
	
}
