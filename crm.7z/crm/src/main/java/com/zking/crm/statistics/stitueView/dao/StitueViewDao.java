package com.zking.crm.statistics.stitueView.dao;

import java.util.List;

import com.zking.crm.common.dao.BaseDao;
import com.zking.crm.statistics.stitueView.model.StitueView;

public class StitueViewDao extends BaseDao implements IStitueViewDao{

	@Override
	public List<StitueView> listStitueView() {
		String hql = "select s from StitueView s";
		List<StitueView> list = (List<StitueView>)this.getHibernateTemplate().find(hql);
		return list;
	}

}
