package com.zking.crm.statistics.stituemydview.dao;

import java.util.List;

import com.zking.crm.common.dao.BaseDao;
import com.zking.crm.statistics.stitueView.model.StitueView;
import com.zking.crm.statistics.stituemydview.model.StitueMydView;

public class StitueMydViewDao extends BaseDao implements IStitueMydViewDao{

	@Override
	public List<StitueMydView> listStitueView() {
		String hql = "select s from StitueMydView s";
		List<StitueMydView> list = (List<StitueMydView>)this.getHibernateTemplate().find(hql);
		return list;
	}

}
