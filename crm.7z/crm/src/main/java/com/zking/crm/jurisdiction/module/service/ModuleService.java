package com.zking.crm.jurisdiction.module.service;

import java.util.List;

import com.zking.crm.jurisdiction.module.dao.IModuleDao;
import com.zking.crm.jurisdiction.module.model.Module;


public class ModuleService implements IModuleService {
	
	private IModuleDao moduleDao;

	public IModuleDao getModuleDao() {
		return moduleDao;
	}
	
	public void setModuleDao(IModuleDao moduleDao) {
		this.moduleDao = moduleDao;
	}

	@Override
	public List<Module> getModules() {
		return moduleDao.getModules(-1);
	}

}
