package com.zking.crm.serve.cstserviceview.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.security.auth.message.callback.PrivateKeyCallback.Request;
import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ModelDriven;
import com.zking.crm.common.action.BaseAction;
import com.zking.crm.serve.cstserviceview.model.CstServiceView;
import com.zking.crm.serve.cstserviceview.service.ICstServiceViewService;

public class CstServiceViewAction extends BaseAction implements ModelDriven<CstServiceView> {

	private CstServiceView cstServiceView = new CstServiceView();

	@Override
	public CstServiceView getModel() {
		return cstServiceView;
	}

	private ICstServiceViewService cstServiceViewService;

	public ICstServiceViewService getCstServiceViewService() {
		return cstServiceViewService;
	}

	public void setCstServiceViewService(ICstServiceViewService cstServiceViewService) {
		this.cstServiceViewService = cstServiceViewService;
	}

	public void listCstServiceView() {
		Map<String, Object> map = new HashMap<>();
		List<CstServiceView> cstServiceViews = cstServiceViewService.listCstServiceView(cstServiceView);
		System.out.println(cstServiceViews);
		map.put("cstServiceViews", cstServiceViews);
		this.writeAsJson(map);
	}

	public void listCdate() {
		Map<String, Object> map = new HashMap<>();
		List<CstServiceView> cdates = cstServiceViewService.listCdate();
		map.put("cdates", cdates);
		this.writeAsJson(map);
	}
	public void addCount() {
		System.out.println(cstServiceView);
		Map<String, Object> map = new HashMap<>();
		try {
			cstServiceViewService.addCount(cstServiceView);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		this.writeAsJson(map);
	}
	public void listServiceView() {
		Map<String, Object> map = new HashMap<>();
		List<CstServiceView> csts = cstServiceViewService.listServiceView(Integer.parseInt(cstServiceView.getCdate()));
		map.put("csts", csts);
		System.out.println(csts);
		this.writeAsJson(map);
	}
	public void findCdate() {
		Map<String, Object> map = new HashMap<>();
		List<CstServiceView> csts = cstServiceViewService.listCdate(Integer.parseInt(cstServiceView.getCdate()));
		map.put("cdates", csts);
		this.writeAsJson(map);
	}
//	public void listServiceView() {
//		HttpServletRequest request = ServletActionContext.getRequest();
//		String[] datas = {};
//		datas = request.getParameterValues("dates");
//		System.out.println("datas测试"+datas);
//		Map<String, Object> map = new HashMap<>();
//		List<List<CstServiceView>> csts = cstServiceViewService.listServiceView(datas);
//		System.out.println("csts测试"+csts);
//		map.put("csts", csts);
//		this.writeAsJson(map);
//		
//	}
}
