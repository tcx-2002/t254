package com.zking.crm.common.dao;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.orm.hibernate5.HibernateCallback;
import org.springframework.orm.hibernate5.support.HibernateDaoSupport;

import com.zking.crm.util.PageBean;


public abstract class BaseDao extends HibernateDaoSupport {
	
	
	/**
     * 分页查询
     * @param hql 传入的<u>hql</u>语句
     * @param params 查询参数
     * @param pageBean 分页对象
     * @return
     */
    @SuppressWarnings({ "unchecked", "rawtypes" })
    protected List query(final String hql, final Map<String,Object> params, final PageBean pageBean) {

        /*
         * 1. 以下方式可以获取session，但需要自行处理开启事务，处理关闭等操作操作
         * Session session = this.getHibernateTemplate().getSessionFactory().openSession();
         * 2. 使用回调的方式，由hibernateTemplate来管理session
         */
        List data = (List)this.getHibernateTemplate().execute(new HibernateCallback() {           

            @Override
            public Object doInHibernate(Session session) throws HibernateException {
               
            	Query query = null;
                //1.获取总记录数    
            	if(pageBean != null && pageBean.isPagination()) {
            		String countHql = getCountHql(hql);
            		query = session.createQuery(countHql);
                    setParameters(query, params);
                    Object total = query.uniqueResult();
                    pageBean.setTotal(Integer.valueOf(total.toString()));
            	}

                //2.获取分页数据 
            	if(pageBean != null && pageBean.isPagination()) {
            		query = session.createQuery(hql);
                    //指定开始记录下标
                    query.setFirstResult(pageBean.getStartIndex());
                    //指定返回记录数
                    query.setMaxResults(pageBean.getRows());
      
            	}
            	setParameters(query, params);
            	
            	return query.list();

                
            }
        });
        
        return data;
    }
    
    
    /**
     * 传入的hql语句，例如：
     * from account a where 1=1 and a.userName =: userName order by a.balance;
     * 或
     * select a.userName, a.balance from account a where 1=1 
     *           and a.userName = :userName order by a.balance;;
     * 期望的结果为：
     * select count(*) from account a where 1=1 and a.userName = :userName
     * 
     * 注意，hql的统计总记录数的语句不能包含order by子句
     * 
     * @param hql
     * @return
     */
    private String getCountHql(String hql) {
    	
    	String tmp = hql.toLowerCase();
    	
    	int formIndex = tmp.indexOf("from ");
    	int orderByIndex = tmp.indexOf("order by ");
    	
    	String rhql = "";
    	if(orderByIndex == -1) {
    		rhql = "select count(*) " + hql.substring(formIndex);
    	} else {
    		rhql = "select count(*) " + hql.substring(formIndex, orderByIndex);
    	}
    	
    	return rhql;
    }
    
    /*
     * 遍历参数Map，完成hql的参数设置
     * 1. 一般的参数都可以通过query.setParameter(key, val)赋值
     * 2. 但在hql中包含in子句时不能使用上面的方式赋值，需要特殊处理
     *    a）以Collection集合传递in子句的条件
     *      query.setParameterList(key, (Collection)val)
     *    b）以对象数组来传递in子句条件
     *      query.setParameterList(key, (Object[])val)
     */
    private void setParameters(Query query, Map<String,Object> paramMap) {
    	
    	if(paramMap == null || paramMap.size() <=0 ) {
    		return;
    	}
    	/*
    	 * select * from account a where a.id in(.........)
    	 */
    	
    	for(Entry<String,Object> entry: paramMap.entrySet()) {
    		
    		String key = entry.getKey();
            Object val = entry.getValue();
            
            if(val == null) continue;
            
            if(val instanceof Collection) {
            	query.setParameterList(key, (Collection)val);
            } else if(val instanceof Object[]) {
            	query.setParameterList(key, (Object[])val);
            } else {
            	query.setParameter(key, val);
            }
    		
    	}
    	
    	
    }
}
