package com.zking.crm.jurisdiction.user.dao;

import java.io.Serializable;
import java.util.List;

import com.zking.crm.common.dao.BaseDao;
import com.zking.crm.jurisdiction.user.model.User;

public class UserDao extends BaseDao implements IUserDao{

	@Override
	public User login(User user) {
		String hql= "select u from User u where u.usrName=? and u.usrPassword=?";   
		List<User> list = (List<User>) this.getHibernateTemplate().find(hql, new String[]{user.getUsrName(), user.getUsrPassword()}); 
		if(list.size()<1) {
	    	return null;
	    }
	    return list.get(0);
	}

	@Override
	public Integer addUser(User user) {
		Serializable Serializable  = this.getHibernateTemplate().save(user);
		return Integer.parseInt(Serializable.toString());
	}

	@Override
	public List<User> userAM() {
		String hql = "select u from User u where u.usrRoleId=3 and u.usrFlag=1";
		List<User> list =(List<User>) this.getHibernateTemplate().find(hql);
		return list;
	}

	@Override
	public User userById(Integer usrId) {
		String hql = "select u from User u where u.usrId=?";
		List<User> list = (List<User>) this.getHibernateTemplate().find(hql, usrId); 
		if(list.size()<1) {
	    	return null;
	    }
	    return list.get(0);
	}

	@Override
	public List<User> selCustManagerName(Integer usrRoleId) {
		String hql = "from User u where u.usrRoleId = ?";
		List<User> list = (List<User>) this.getHibernateTemplate().find(hql, usrRoleId);
		return list;
	}

}
