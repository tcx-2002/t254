package com.zking.crm.basics.basdict.dao;

import java.util.List;

import com.zking.crm.basics.basdict.model.BasDict;
import com.zking.crm.util.PageBean;

public interface IBasDictDao {
	/**
	 * 分页查询所有字典
	 * @param basDict
	 * @param pageBean
	 * @return
	 */
List<BasDict> listBasDict(BasDict basDict,PageBean pageBean);
/**
 * 增加一个字典
 * @param basDict
 * @return
 */
Integer addBasDict(BasDict basDict);
/**
 * 修改一个字典
 * @param basDict
 */
void updateBasDict(BasDict basDict);
/**
 * 删除一个字典
 * @param dictID
 */
void deleteBasDict(int dictID);
/**
 * 删除一个条目下的所有字典
 * @param dictItem
 */
void deleteBasDictByItem(String dictItem);
/**
 * 通过字典条目查询字典
 * @param dictItem
 * @return
 */
List<BasDict> basDictByDictItem(String dictItem);
/**
 * 通过字典id查询
 * @param dictID
 * @return
 */
BasDict basDictById(int dictID);


/**
 *查询管理用户
 */
public List<BasDict> selCustAddrs(String dictItem);


/**
 *查询客户经理
 */
public List<BasDict> selCustManagerName(String dictItem);



/**
 *查询客户满意度 
 */
public List<BasDict> selCustSatisfy(String dictItem);



/**
 *查询客户等级
 */
public List<BasDict> selCustLevelLabel(String dictItem);


/**
 *查询客户信用度 
 */
public List<BasDict> selCustCredit(String dictItem);


/**
 * 查询客户等级
 * @param dictId
 * @return
 */
public BasDict selCstCustomerLevel(Integer dictID);

}
