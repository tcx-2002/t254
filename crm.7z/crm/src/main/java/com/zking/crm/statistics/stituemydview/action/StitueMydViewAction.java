package com.zking.crm.statistics.stituemydview.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.opensymphony.xwork2.ModelDriven;
import com.zking.crm.common.action.BaseAction;
import com.zking.crm.statistics.stitueView.model.StitueView;
import com.zking.crm.statistics.stitueView.service.IStitueViewService;
import com.zking.crm.statistics.stituemydview.model.StitueMydView;
import com.zking.crm.statistics.stituemydview.service.IStitueMydViewService;

public class StitueMydViewAction extends BaseAction implements ModelDriven<StitueMydView>{
private StitueMydView stitueMydView = new StitueMydView();

@Override
public StitueMydView getModel() {
	// TODO Auto-generated method stub
	return stitueMydView;
}

private IStitueMydViewService stitueMydViewService;


public IStitueMydViewService getStitueMydViewService() {
	return stitueMydViewService;
}


public void setStitueMydViewService(IStitueMydViewService stitueMydViewService) {
	this.stitueMydViewService = stitueMydViewService;
}


public void listStitueMydView() {
	Map<String, Object> map = new HashMap<>();
	List<StitueMydView> stitues = stitueMydViewService.listStitueView();
	map.put("stitues", stitues);
	this.writeAsJson(map);
}
}
