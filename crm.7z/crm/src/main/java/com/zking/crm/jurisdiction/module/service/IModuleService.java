package com.zking.crm.jurisdiction.module.service;

import java.util.List;

import com.zking.crm.jurisdiction.module.model.Module;


public interface IModuleService {
	
	public List<Module> getModules() ;

}
