package com.zking.crm.client.constitue.service;

import java.util.List;

import com.zking.crm.client.constitue.model.Constitue;

public interface IConstitueService {
	/**
	 * 通过类型查看统计报表
	 * @param constitue
	 * @return
	 */
	List<Constitue> listConstitue(Constitue constitue);
	/**
	 * 查询出所有查看方式
	 * @return
	 */
	List<Constitue> listType();
}
